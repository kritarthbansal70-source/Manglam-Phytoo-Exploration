import React, { useState, useMemo, useEffect, useRef } from "react";
import { AnimatePresence, motion, useReducedMotion, useScroll, useTransform, type Variants } from "framer-motion";
import { ArrowDown, ArrowRight, Pause, Play, Search, Settings2, SlidersHorizontal, X } from "lucide-react";
import { BotanicalCanvas } from "./components/BotanicalCanvas";
import { CheckoutDrawer } from "./components/CheckoutDrawer";
import { SiteHeader } from "./components/SiteHeader";
import { Dialog } from "./components/Dialog";
import { BackToTop, CountUp, Parallax, Reveal, ScrollLine, ScrollMarquee, Stagger, StaggerItem, TiltCard, useScrollFade } from "./components/ScrollEffects";
import { AdminPanel } from "./components/AdminPanel";
import { downloadText, formatMoney, getVolumeTier, linePricing, loadCart, normalizeQuantity, persistCart, SAMPLE_GRAMS, samplePrice, type CartItem, type Currency, type Product } from "./lib/commerce";
import { formatPhone, loadConfig, telLink, waLink, type SiteConfig } from "./lib/siteConfig";

const heroEntrance: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function App() {
  const [config, setConfig] = useState<SiteConfig>(() => loadConfig());
  const [adminOpen, setAdminOpen] = useState(false);
  const PRODUCTS = config.products;
  const contact = config.contact;
  const [currency, setCurrency] = useState<Currency>("INR");
  const [selectedProductForCoa, setSelectedProductForCoa] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [productSort, setProductSort] = useState("featured");
  const [scenePaused, setScenePaused] = useState(false);
  const heroRef = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress: heroProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroParallax = useTransform(heroProgress, [0, 1], [0, 150]);
  const heroFade = useScrollFade(heroRef);
  const processRef = useRef<HTMLDivElement>(null);

  // Bulk Calculator state
  const [calcProductId, setCalcProductId] = useState<string>("gymnema-75");
  const [calcQuantity, setCalcQuantity] = useState<number>(100);
  const [calcQuantityDraft, setCalcQuantityDraft] = useState("100");
  useEffect(() => setCalcQuantityDraft(String(calcQuantity)), [calcQuantity]);

  // Cart / RFQ drawer
  const [rfqItems, setRfqItems] = useState<CartItem[]>(() => loadCart(PRODUCTS));
  const [rfqDrawerOpen, setRfqDrawerOpen] = useState(false);

  useEffect(() => persistCart(rfqItems), [rfqItems]);

  // When admin edits products, refresh cart lines with the latest prices and drop removed products.
  const applyConfig = (next: SiteConfig) => {
    setConfig(next);
    setRfqItems((items) =>
      items
        .map((item) => { const p = next.products.find((x) => x.id === item.product.id); return p ? { ...item, product: p } : null; })
        .filter((x): x is CartItem => x !== null),
    );
    if (!next.products.some((p) => p.id === calcProductId)) setCalcProductId(next.products[0]?.id ?? "");
  };

  // Open the admin panel via #admin in the URL (e.g. yoursite.com/#admin).
  useEffect(() => {
    const check = () => { if (window.location.hash === "#admin") { setAdminOpen(true); history.replaceState(null, "", window.location.pathname + window.location.search); } };
    check();
    window.addEventListener("hashchange", check);
    return () => window.removeEventListener("hashchange", check);
  }, []);

  const filteredProducts = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const matches = PRODUCTS.filter((product) => `${product.name} ${product.botanical} ${product.assay}`.toLowerCase().includes(query));
    if (productSort === "price-low") matches.sort((a, b) => a.priceInr - b.priceInr);
    if (productSort === "price-high") matches.sort((a, b) => b.priceInr - a.priceInr);
    return matches;
  }, [searchQuery, productSort, PRODUCTS]);

  // Quick inquiry state
  const [inquiryName, setInquiryName] = useState("");
  const [inquiryCompany, setInquiryCompany] = useState("");
  const [inquiryEmail, setInquiryEmail] = useState("");
  const [inquiryPhone, setInquiryPhone] = useState("");
  const [inquiryNotes, setInquiryNotes] = useState("");
  const [inquirySuccess, setInquirySuccess] = useState(false);


  const activeCalcProduct = useMemo(() => {
    return PRODUCTS.find((p) => p.id === calcProductId) || PRODUCTS[0];
  }, [calcProductId, PRODUCTS]);

  const discountTier = getVolumeTier(calcQuantity);
  const calcPricing = linePricing({ product: activeCalcProduct, qty: calcQuantity, type: "commercial" }, currency);
  const calcUnitPrice = calcPricing.unit;
  const calcTotalPrice = calcPricing.total;

  const addToRfq = (product: Product, type: "sample" | "commercial", qty = type === "sample" ? 1 : 25) => {
    setRfqItems((prev) => {
      const existing = prev.find((i) => i.product.id === product.id && i.type === type);
      if (existing) {
        return prev.map((i) => (i === existing ? { ...i, qty: normalizeQuantity(i.qty + qty, type) } : i));
      }
      return [...prev, { product, qty: normalizeQuantity(qty, type), type }];
    });
    setRfqDrawerOpen(true);
  };

  const removeFromRfq = (index: number) => {
    setRfqItems((prev) => prev.filter((_, i) => i !== index));
  };

  const updateRfqQuantity = (index: number, quantity: number) => {
    setRfqItems((items) => items.map((item, i) => i === index ? { ...item, qty: normalizeQuantity(quantity, item.type) } : item));
  };

  const handleQuickInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    downloadText("manglam-ingredient-brief.txt", [
      "MANGLAM PHYTOO EXPLORATION - INGREDIENT BRIEF",
      `Name: ${inquiryName.trim()}`, `Company: ${inquiryCompany.trim()}`,
      `Email: ${inquiryEmail.trim()}`, `Phone: ${inquiryPhone.trim()}`,
      "", inquiryNotes.trim(), "", "Prepared locally. Share with your verified sales contact. This brief has not been sent.",
    ].join("\n"));
    setInquirySuccess(true);
  };

  const formatPrice = (valInr: number, valUsd: number) => {
    if (currency === "INR") {
      return `₹${valInr.toLocaleString("en-IN")}`;
    }
    return `$${valUsd.toFixed(2)}`;
  };

  const factoryLine = `${contact.addressLine1} ${contact.addressLine2}, ${contact.city} ${contact.postalCode}, ${contact.region}`.replace(/\s+,/g, ",");
  const deskLine = [contact.desk1 && `Desk 1: ${formatPhone(contact.desk1)}`, contact.desk2 && `Desk 2: ${formatPhone(contact.desk2)}`].filter(Boolean).join(" | ");
  const whatsappMessage = encodeURIComponent(
    `Hello ${contact.companyName},\n\nI am contacting you from the website regarding B2B bulk supply of standardized botanical extracts.\n\n${deskLine}\nFactory: ${factoryLine}\n\nProducts of interest:\n${PRODUCTS.map((p) => `- ${p.name} (₹${p.priceInr.toLocaleString("en-IN")} / $${p.priceUsd.toFixed(2)})`).join("\n")}\n\nPlease share latest batch COAs and lead times.`
  );
  const primaryWhatsapp = contact.whatsapp1 || contact.whatsapp2 || contact.desk1;

  return (
    <div className="min-h-screen bg-surface font-body-md text-on-surface antialiased selection:bg-tertiary-fixed selection:text-primary">
      <a className="skip-link" href="#main-content">Skip to content</a>
      {/* Top Banner / Regulatory Notification */}
      <div className="bg-primary-container text-primary-fixed text-xs py-2 px-4 border-b border-primary/20 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 mx-auto lg:mx-0">
          <span className="flex h-2 w-2 rounded-full bg-tertiary-fixed animate-pulse"></span>
          <span className="font-mono-data text-[11px] uppercase tracking-wider text-tertiary-fixed">
            Q1 Export Allocation Open
          </span>
          <span className="hidden sm:inline text-on-primary-container/80">
            • Freshly released lots: Gymnema 75%, Berberine HCl 60%+, Ashwagandha Water 2.7% &amp; 5%+, Methidana 50%+
          </span>
        </div>
        <div className="hidden lg:flex items-center gap-6 font-mono-data text-[11px] text-primary-fixed/80">
          <span>cGMP &amp; ISO 9001:2015</span>
          <span>•</span>
          <span>Zero Ethylene Oxide Guarantee</span>
          <span>•</span>
          <span>Worldwide Freight (Nhava Sheva / Air)</span>
        </div>
      </div>

      <SiteHeader currency={currency} onCurrencyChange={setCurrency} itemCount={rfqItems.length} onOpenCart={() => setRfqDrawerOpen(true)} />

      <main id="main-content" tabIndex={-1}>
      {/* Hero Section with Interactive 3D Botanical Tree & Active Molecules */}
      <section ref={heroRef} id="hero" aria-labelledby="hero-heading" className="relative min-h-[90svh] flex items-center bg-primary overflow-hidden pt-14 pb-24 sm:pt-20 sm:pb-28">
        {/* Three.js 3D Scene Canvas Background */}
        <motion.div aria-hidden="true" style={{ y: reduceMotion || scenePaused ? 0 : heroParallax }} className="absolute inset-0 z-0 opacity-90 pointer-events-none">
          <BotanicalCanvas paused={scenePaused} />
        </motion.div>

        {/* Ambient Botanical Vignettes */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/80 to-primary/10 pointer-events-none z-[1]" />
        <div className="absolute bottom-0 inset-x-0 h-32 bg-gradient-to-t from-primary via-primary/40 to-transparent pointer-events-none z-[2]" />

        {/* Hero Content — fades, shrinks and blurs as the user scrolls away */}
        <motion.div style={heroFade} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full will-change-transform">
          <motion.div initial={reduceMotion ? false : "hidden"} animate="visible" variants={{ visible: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } } }} className="max-w-3xl flex flex-col gap-6">
            <motion.div variants={heroEntrance} className="inline-flex items-center gap-3">
              <span className="h-px w-8 bg-tertiary-fixed/65" />
              <span className="font-label-caps text-[10px] text-tertiary-fixed tracking-[0.22em] uppercase font-semibold sm:text-xs">
                Manglam Phytoo Exploration
              </span>
            </motion.div>

            <motion.h1 variants={heroEntrance} id="hero-heading" className="font-display-lg text-[clamp(2.7rem,5.5vw,5.2rem)] font-medium text-on-primary leading-[1.05] tracking-[-0.045em]">
              Sourcing the Forest.<br />
              <span className="text-tertiary-fixed font-normal">Standardizing Science.</span>
            </motion.h1>

            <motion.p variants={heroEntrance} className="font-body-lg text-base sm:text-lg text-on-primary/70 leading-relaxed max-w-xl">
              India&apos;s B2B supply chain for botanical extracts. From indigenous forest wisdom to the precision your next formulation demands.
            </motion.p>

            {/* CTAs */}
            <motion.div variants={heroEntrance} className="flex flex-wrap gap-3 pt-2">
              <a
                href="#products"
                className="interactive-button group min-h-12 px-6 py-3.5 rounded bg-tertiary-fixed text-primary text-sm font-semibold flex items-center gap-5 hover:bg-tertiary-fixed-dim"
              >
                <span>Explore extracts</span>
                <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </a>

              <a
                href="#calculator"
                className="interactive-button min-h-12 px-6 py-3.5 rounded bg-transparent border border-on-primary/25 text-on-primary text-sm font-medium flex items-center gap-2.5 hover:bg-on-primary/10 backdrop-blur-sm"
              >
                <span>Build your bulk order</span>
              </a>
            </motion.div>

            {/* Key Trust Data Grid — numbers count up on entry */}
            <motion.div variants={heroEntrance} className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-6 border-t border-on-primary/15 pt-8">
              <div className="flex flex-col">
                <CountUp value={450} suffix="+" duration={1.8} className="font-mono-data text-tertiary-fixed text-2xl sm:text-3xl font-bold" />
                <span className="font-label-caps text-[10px] text-on-primary/60 tracking-widest uppercase mt-1">
                  Botanical Species Verified
                </span>
              </div>
              <div className="flex flex-col">
                <CountUp value={99.8} suffix="%" decimals={1} duration={1.8} className="font-mono-data text-tertiary-fixed text-2xl sm:text-3xl font-bold" />
                <span className="font-label-caps text-[10px] text-on-primary/60 tracking-widest uppercase mt-1">
                  Batch Purity Standard
                </span>
              </div>
              <div className="flex flex-col">
                <span className="font-mono-data text-tertiary-fixed text-2xl sm:text-3xl font-bold">GMP</span>
                <span className="font-label-caps text-[10px] text-on-primary/60 tracking-widest uppercase mt-1">
                  Audited Cleanroom Facility
                </span>
              </div>
              <div className="flex flex-col">
                <span className="font-mono-data text-tertiary-fixed text-2xl sm:text-3xl font-bold">COA</span>
                <span className="font-label-caps text-[10px] text-on-primary/60 tracking-widest uppercase mt-1">
                  Full Batch Traceability
                </span>
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
        <div className="absolute inset-x-0 bottom-6 z-10 mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <a href="#products" className="group inline-flex min-h-10 items-center gap-3 text-[10px] uppercase tracking-[0.16em] text-white/65 hover:text-tertiary-fixed"><ArrowDown size={14} className="transition-transform group-hover:translate-y-1" aria-hidden="true" /> Scroll to explore</a>
          {!reduceMotion && <button type="button" onClick={() => setScenePaused((paused) => !paused)} aria-pressed={scenePaused} className="inline-flex min-h-10 items-center gap-2 text-[11px] text-white/65 hover:text-tertiary-fixed">{scenePaused ? <Play size={12} aria-hidden="true" /> : <Pause size={12} aria-hidden="true" />}{scenePaused ? "Resume scene" : "Pause scene"}</button>}
        </div>
      </section>

      {/* Live Market Price Standards Bar */}
      <section className="bg-surface-container-high border-y border-outline-variant/40 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-600 animate-ping"></span>
            <span className="font-label-caps text-xs font-bold tracking-widest text-primary uppercase">
              Spot Factory Direct Pricing (Ex-Works / FOB)
            </span>
          </div>

          <Stagger stagger={0.06} className={`grid grid-cols-2 sm:grid-cols-3 ${PRODUCTS.length >= 5 ? "lg:grid-cols-5" : "lg:grid-cols-4"} gap-4 sm:gap-6 text-xs font-mono-data w-full md:w-auto`}>
            {PRODUCTS.map((p) => (
              <StaggerItem key={p.id} direction="up" distance={14} className="bg-surface p-2.5 rounded border border-outline-variant/60 flex flex-col min-w-0 transition-colors hover:border-tertiary/60">
                <span className="text-[11px] text-on-surface-variant truncate" title={p.name}>{p.name.replace(/ Extract/i, "").replace(/Water/i, "W.")}</span>
                <span className="font-bold text-primary text-sm">{formatPrice(p.priceInr, p.priceUsd)} <span className="text-[10px] font-normal text-on-surface-variant">/kg</span></span>
              </StaggerItem>
            ))}
          </Stagger>
        </div>
      </section>

      {/* Scroll-reactive marquee — direction follows scroll direction */}
      <ScrollMarquee
        className="border-b border-outline-variant/40 bg-surface py-3"
        items={["Wild-harvested botanicals", "HPLC standardized", "ICP-MS heavy metal screened", "Zero ethylene oxide", "GMP audited facility", "50 g sample kits", "Ramnagar, Uttarakhand", "Batch COA with every drum"]}
      />

      {/* Primary Products & Inventory Bento Section */}
      <section id="products" className="py-24 bg-surface max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
          <div>
            <span className="font-label-caps text-xs font-bold text-secondary tracking-[0.25em] uppercase block mb-2">
              Featured Phytochemical Portfolio
            </span>
            <h2 className="font-headline-md text-3xl sm:text-4xl text-on-surface">
              Standardized Extracts <span className="italic font-normal text-primary">&bull; Live Factory Inventory</span>
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs font-mono-data text-on-surface-variant">
              Currency shown in:
            </span>
            <div className="inline-flex rounded border border-outline/30 bg-surface-container p-0.5 text-xs font-mono-data">
              <button
                onClick={() => setCurrency("INR")}
                aria-pressed={currency === "INR"}
                className={`px-3 py-1 rounded font-bold transition-all ${
                  currency === "INR" ? "bg-primary text-on-primary" : "text-on-surface hover:text-primary"
                }`}
              >
                ₹ INR
              </button>
              <button
                onClick={() => setCurrency("USD")}
                aria-pressed={currency === "USD"}
                className={`px-3 py-1 rounded font-bold transition-all ${
                  currency === "USD" ? "bg-primary text-on-primary" : "text-on-surface hover:text-primary"
                }`}
              >
                $ USD
              </button>
            </div>
            <a
              href="#calculator"
              className="text-xs font-semibold text-tertiary hover:underline flex items-center gap-1 ml-2"
            >
              <span className="material-symbols-outlined text-[16px]">tune</span>
              Bulk Volume Discounts
            </a>
          </div>
        </Reveal>

        <div className="mb-8 flex flex-col gap-4 border-y border-outline-variant/55 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex min-h-11 items-center gap-3 sm:w-[45%]">
            <Search size={17} className="shrink-0 text-secondary" aria-hidden="true" />
            <label htmlFor="product-search" className="sr-only">Search botanical extracts</label>
            <input id="product-search" type="search" value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} placeholder="Find your botanical extract..." className="min-w-0 flex-1 bg-transparent py-2 text-sm text-primary outline-none placeholder:text-outline" />
            {searchQuery && <button type="button" onClick={() => setSearchQuery("")} aria-label="Clear product search" className="grid h-9 w-9 place-items-center rounded text-secondary hover:bg-surface-container"><X size={15} /></button>}
          </div>
          <div className="flex items-center justify-between gap-5">
            <span className="text-[11px] text-outline" role="status" aria-live="polite">{filteredProducts.length} {filteredProducts.length === 1 ? "extract" : "extracts"}</span>
            <div className="flex items-center gap-2 border-l border-outline-variant/50 pl-5"><SlidersHorizontal size={13} className="text-secondary" aria-hidden="true" /><label htmlFor="product-sort" className="sr-only">Sort products</label><select id="product-sort" value={productSort} onChange={(event) => setProductSort(event.target.value)} className="min-h-10 max-w-44 bg-transparent pr-1 text-xs font-medium text-primary"><option value="featured">Featured first</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option></select></div>
          </div>
        </div>

        {/* 4 Cards Grid - Tailored with exact requested pricing and spec data */}
        <motion.div layout={!reduceMotion} className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <AnimatePresence mode="popLayout">
          {filteredProducts.map((prod, index) => (
            <motion.div
              key={prod.id}
              layout={!reduceMotion}
              initial={reduceMotion ? false : { opacity: 0, y: 40, x: index % 2 === 0 ? -18 : 18 }}
              whileInView={{ opacity: 1, y: 0, x: 0 }}
              viewport={{ once: true, amount: 0.12 }}
              exit={{ opacity: 0, scale: reduceMotion ? 1 : 0.98 }}
              transition={{ duration: 0.6, delay: (index % 2) * 0.1, ease: [0.22, 1, 0.36, 1], layout: { duration: 0.35 } }}
              className="min-w-0"
            >
            <TiltCard className="product-card relative h-full min-w-0 overflow-hidden bg-surface-container-low border border-outline-variant/60 rounded-lg flex flex-col justify-between hover:border-tertiary/50 hover:shadow-[0_18px_44px_#08270e14] group">
              {/* Product Image — drifts on scroll, zooms on hover */}
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-surface-container">
                <Parallax speed={0.12} className="absolute inset-[-12%]">
                  <img
                    src={prod.image}
                    alt={`${prod.name} — ${prod.botanical}`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
                  />
                </Parallax>
                {prod.popular && (
                  <span className="absolute left-3 top-3 font-label-caps text-[10px] tracking-wider uppercase font-bold px-2.5 py-1 rounded bg-tertiary-fixed text-on-tertiary-fixed shadow-sm">
                    High Demand Export
                  </span>
                )}
                <span className="absolute right-3 top-3 font-mono-data text-[11px] px-2 py-1 rounded bg-surface/90 backdrop-blur-sm border border-outline-variant/50 text-secondary font-bold">
                  #{prod.batchNo}
                </span>
              </div>

              <div className="p-5 sm:p-8 flex flex-col justify-between flex-1">
              {/* Title & Botanical Info */}
              <div>
                <h3 className="font-display-lg text-2xl font-bold text-on-surface group-hover:text-primary transition-colors">
                  {prod.name}
                </h3>
                <p className="font-mono-data text-xs text-secondary mt-1 italic">
                  {prod.botanical} &bull; {prod.part}
                </p>

                {/* Assay & Specs Tag Box */}
                <div className="product-specs my-5 p-4 rounded bg-surface border border-outline-variant/40 space-y-2 text-xs">
                  <div className="flex justify-between items-center border-b border-outline-variant/20 pb-1.5">
                    <span className="font-semibold text-on-surface">Standardized Active:</span>
                    <span className="font-mono-data font-bold text-primary">{prod.assay}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-outline-variant/20 pb-1.5">
                    <span className="text-on-surface-variant">Physical Appearance:</span>
                    <span className="font-mono-data text-on-surface truncate max-w-[240px]">{prod.appearance}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-on-surface-variant">Loss on Drying:</span>
                    <span className="font-mono-data text-on-surface">{prod.lossOnDrying}</span>
                  </div>
                </div>

                {/* Application Pills */}
                <div className="flex flex-wrap gap-1.5 mb-6">
                  {prod.applications.map((app) => (
                    <span
                      key={app}
                      className="text-[11px] font-medium px-2 py-0.5 rounded bg-surface-container border border-outline-variant/30 text-on-surface-variant"
                    >
                      {app}
                    </span>
                  ))}
                </div>
              </div>

              {/* Pricing & Order Actions */}
              <div className="border-t border-outline-variant/40 pt-5 mt-auto">
                <div className="flex items-baseline justify-between mb-4">
                  <div>
                    <span className="font-label-caps text-[10px] text-on-surface-variant tracking-wider uppercase block">
                      Wholesale Drum Rate
                    </span>
                    <div className="flex items-baseline gap-1.5">
                      <motion.span key={currency} initial={{ opacity: 0, y: reduceMotion ? 0 : 5 }} animate={{ opacity: 1, y: 0 }} className="price-value font-display-lg text-3xl font-medium text-primary">
                        {formatPrice(prod.priceInr, prod.priceUsd)}
                      </motion.span>
                      <span className="font-mono-data text-xs text-on-surface-variant">/ kg</span>
                    </div>
                  </div>
                  <span className="font-mono-data text-[10px] text-secondary bg-secondary/10 px-2 py-1 rounded">
                    MOQ: 25 kg Drum
                  </span>
                </div>

                {samplePrice(prod, currency) !== null && (
                  <div className="mb-4 flex items-center justify-between rounded border border-tertiary/30 bg-tertiary/5 px-3 py-2">
                    <span className="flex items-center gap-1.5 text-[11px] font-semibold text-primary">
                      <span className="material-symbols-outlined text-[15px] text-tertiary" aria-hidden="true">science</span>
                      Sample kit &bull; {SAMPLE_GRAMS} g
                    </span>
                    <span className="price-value font-mono-data text-sm font-bold text-primary">
                      {formatMoney(samplePrice(prod, currency)!, currency)}
                      <span className="ml-1 text-[10px] font-normal text-on-surface-variant">/ {SAMPLE_GRAMS} g</span>
                    </span>
                  </div>
                )}

                <div className="grid grid-cols-2 min-[400px]:grid-cols-3 gap-2">
                  <button
                    onClick={() => setSelectedProductForCoa(prod)}
                    aria-label={`View specifications for ${prod.name}`}
                    className="interactive-button min-h-11 px-2.5 py-2.5 rounded border border-outline text-on-surface hover:bg-surface-container-high text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <span className="material-symbols-outlined text-[15px]">description</span>
                    <span>Spec / COA</span>
                  </button>

                  <button
                    onClick={() => addToRfq(prod, "sample", 1)}
                    aria-label={`Add ${prod.name} sample kit to cart`}
                    className="interactive-button min-h-11 px-2.5 py-2.5 rounded bg-surface-container-highest hover:bg-surface-container-high text-primary border border-outline-variant/80 text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <span className="material-symbols-outlined text-[15px]">science</span>
                    <span>{SAMPLE_GRAMS} g Sample</span>
                  </button>

                  <button
                    onClick={() => addToRfq(prod, "commercial", 25)}
                    aria-label={`Add 25 kg of ${prod.name} to cart`}
                    className="interactive-button col-span-2 min-[400px]:col-span-1 min-h-11 px-2.5 py-2.5 rounded bg-primary hover:bg-primary-container text-on-primary text-xs font-semibold flex items-center justify-center gap-1 shadow-sm"
                  >
                    <span className="material-symbols-outlined text-[15px]">add_shopping_cart</span>
                    <span>Add to cart</span>
                  </button>
                </div>
              </div>
              </div>
            </TiltCard>
            </motion.div>
          ))}
          </AnimatePresence>
        </motion.div>
        {filteredProducts.length === 0 && <div className="py-16 text-center"><Search size={26} className="mx-auto mb-4 text-tertiary" aria-hidden="true" /><h3 className="font-display-lg text-2xl text-primary">No extracts found</h3><p className="mt-2 text-sm text-on-surface-variant">Try a botanical name or a different search term.</p><button type="button" onClick={() => { setSearchQuery(""); setProductSort("featured"); }} className="mt-5 min-h-10 text-sm font-semibold text-tertiary underline underline-offset-4">Show all extracts</button></div>}

        {/* Global Export & Logistics Strip */}
        <div className="mt-12 p-6 rounded-lg bg-surface-container border border-outline-variant/60 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded bg-tertiary/15 text-tertiary flex items-center justify-center">
              <span className="material-symbols-outlined text-[28px]">local_shipping</span>
            </div>
            <div>
              <h4 className="font-display-lg text-lg font-bold text-on-surface">
                Palletized Worldwide Dispatch
              </h4>
              <p className="text-xs text-on-surface-variant mt-0.5">
                Standard 25kg fiber drums with dual food-grade polyethylene liners and nitrogen flush. Air charter or sea container directly via Nhava Sheva (JNPT) port.
              </p>
            </div>
          </div>
          <a
            href="#contact"
            className="whitespace-nowrap px-5 py-2.5 rounded bg-tertiary text-on-tertiary font-label-caps text-xs font-bold uppercase tracking-wider hover:bg-tertiary-container transition-colors"
          >
            Custom Specification Request
          </a>
        </div>
      </section>

      {/* Manufacturing Process Section from Design B (5-Step Traceability Protocol) */}
      <section id="process" className="py-28 bg-surface-container-low border-y border-outline-variant/40 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-20">
            <div className="flex flex-col gap-3">
              <span className="font-label-caps text-xs text-secondary tracking-widest uppercase font-bold">
                Transparency In Extraction
              </span>
              <h2 className="font-headline-md text-3xl sm:text-4xl text-on-surface max-w-xl">
                Our Forest-to-Extract <br />
                <span className="italic text-primary font-normal">Traceability Protocol</span>
              </h2>
            </div>
            <p className="text-sm text-on-surface-variant max-w-md">
              Every milligram is tracked from registered tribal cooperative harvest plots through to cryo-milling, supercritical extraction, and pharmacopoeial release testing.
            </p>
          </Reveal>

          <div ref={processRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 relative">
            {/* Connector line that draws itself as the user scrolls through the steps */}
            <div aria-hidden="true" className="pointer-events-none absolute left-0 right-0 top-[52px] hidden h-[2px] lg:block">
              <div className="absolute inset-0 bg-outline-variant/40" />
              <ScrollLine containerRef={processRef} className="absolute inset-0 bg-tertiary" />
            </div>
            <div aria-hidden="true" className="pointer-events-none absolute bottom-0 left-[27px] top-0 w-[2px] lg:hidden">
              <div className="absolute inset-0 bg-outline-variant/40" />
              <ScrollLine containerRef={processRef} orientation="vertical" className="absolute inset-0 bg-tertiary" />
            </div>

            {/* Step 1 */}
            <Reveal direction="up" scale className="flex flex-col gap-5 group relative z-10 bg-surface p-5 rounded-lg border border-outline-variant/40 shadow-sm hover:border-primary/50 hover:-translate-y-1 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-surface-container-high rounded flex items-center justify-center transition-all group-hover:bg-primary group-hover:text-on-primary relative">
                <span className="material-symbols-outlined text-[28px]">forest</span>
                <span className="absolute -top-2 -right-2 font-mono-data text-[11px] bg-tertiary text-on-tertiary px-2 py-0.5 rounded font-bold">
                  01
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h4 className="font-label-caps text-xs text-primary font-bold uppercase tracking-wider">
                  Sourcing &amp; Harvest
                </h4>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Direct partnership with wild-harvesters and organic farm collectives across the Himalayan foothills and Central Indian forests.
                </p>
              </div>
            </Reveal>

            {/* Step 2 */}
            <Reveal delay={0.1} direction="up" scale className="flex flex-col gap-5 group relative z-10 bg-surface p-5 rounded-lg border border-outline-variant/40 shadow-sm hover:border-primary/50 hover:-translate-y-1 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-surface-container-high rounded flex items-center justify-center transition-all group-hover:bg-primary group-hover:text-on-primary relative">
                <span className="material-symbols-outlined text-[28px]">precision_manufacturing</span>
                <span className="absolute -top-2 -right-2 font-mono-data text-[11px] bg-tertiary text-on-tertiary px-2 py-0.5 rounded font-bold">
                  02
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h4 className="font-label-caps text-xs text-primary font-bold uppercase tracking-wider">
                  Cleaning &amp; Cryo-Grinding
                </h4>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Multi-stage purification, magnetic destoning, and temperature-controlled cryogenic milling to preserve volatile bioactives.
                </p>
              </div>
            </Reveal>

            {/* Step 3 */}
            <Reveal delay={0.2} direction="up" scale className="flex flex-col gap-5 group relative z-10 bg-primary text-on-primary p-5 rounded-lg border border-primary-container shadow-xl hover:-translate-y-1 transition-transform">
              <div className="w-14 h-14 bg-tertiary text-on-tertiary rounded flex items-center justify-center relative">
                <span className="material-symbols-outlined text-[28px]">science</span>
                <span className="absolute -top-2 -right-2 font-mono-data text-[11px] bg-tertiary-fixed text-on-tertiary-fixed px-2 py-0.5 rounded font-bold">
                  03
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h4 className="font-label-caps text-xs text-tertiary-fixed font-bold uppercase tracking-wider">
                  Standardized Extraction
                </h4>
                <p className="text-xs text-on-primary/80 leading-relaxed">
                  Supercritical CO2 and closed-loop aqueous processing ensuring solvent-free, high-potency standardized botanical concentrates.
                </p>
              </div>
            </Reveal>

            {/* Step 4 */}
            <Reveal delay={0.3} direction="up" scale className="flex flex-col gap-5 group relative z-10 bg-surface p-5 rounded-lg border border-outline-variant/40 shadow-sm hover:border-primary/50 hover:-translate-y-1 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-surface-container-high rounded flex items-center justify-center transition-all group-hover:bg-primary group-hover:text-on-primary relative">
                <span className="material-symbols-outlined text-[28px]">biotech</span>
                <span className="absolute -top-2 -right-2 font-mono-data text-[11px] bg-tertiary text-on-tertiary px-2 py-0.5 rounded font-bold">
                  04
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h4 className="font-label-caps text-xs text-primary font-bold uppercase tracking-wider">
                  HPLC &amp; ICP-MS Validation
                </h4>
                <span className="font-mono-data text-[10px] text-tertiary font-bold">Assay &bull; Heavy Metals &bull; Microbes</span>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Rigorous validation for heavy metals, residual solvents, pesticides, and active phytochemical marker percentages.
                </p>
              </div>
            </Reveal>

            {/* Step 5 */}
            <Reveal delay={0.4} direction="up" scale className="flex flex-col gap-5 group relative z-10 bg-surface p-5 rounded-lg border border-outline-variant/40 shadow-sm hover:border-primary/50 hover:-translate-y-1 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-surface-container-high rounded flex items-center justify-center transition-all group-hover:bg-primary group-hover:text-on-primary relative">
                <span className="material-symbols-outlined text-[28px]">inventory_2</span>
                <span className="absolute -top-2 -right-2 font-mono-data text-[11px] bg-tertiary text-on-tertiary px-2 py-0.5 rounded font-bold">
                  05
                </span>
              </div>
              <div className="flex flex-col gap-2">
                <h4 className="font-label-caps text-xs text-primary font-bold uppercase tracking-wider">
                  Nitrogen Purge &amp; Dispatch
                </h4>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Oxygen-purged vacuum packaging with tamper-evident batch COA and digital QR provenance tracking on every export drum.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* Interactive Volume & Pricing Calculator */}
      <section id="calculator" className="py-24 bg-surface max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal scale distance={48} amount={0.2} className="bg-primary text-on-primary rounded-2xl p-5 sm:p-12 border border-primary-container shadow-2xl relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-tertiary/20 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="max-w-2xl mb-10">
              <span className="font-label-caps text-xs text-tertiary-fixed font-bold tracking-[0.25em] uppercase block mb-2">
                Commercial Procurement Engine
              </span>
              <h2 className="font-headline-md text-3xl sm:text-4xl text-on-primary">
                B2B Bulk Volume &amp; Price Calculator
              </h2>
              <p className="text-sm text-on-primary/75 mt-2">
                Select an extract and specify your pilot or production batch requirement. Pricing automatically factors in volume tier discounts and packing allocations.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Controls Column */}
              <div className="lg:col-span-7 space-y-6">
                {/* Select Product */}
                <div>
                  <p id="calculator-product-label" className="block text-xs font-mono-data text-primary-fixed uppercase tracking-wider mb-2">
                    1. Select Botanical Extract
                  </p>
                  <div role="group" aria-labelledby="calculator-product-label" className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {PRODUCTS.map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setCalcProductId(p.id)}
                        aria-pressed={calcProductId === p.id}
                        className={`p-3 rounded text-left border transition-all ${
                          calcProductId === p.id
                            ? "bg-tertiary text-on-tertiary border-tertiary-fixed shadow-md"
                            : "bg-primary-container/60 text-on-primary/90 border-primary-container hover:border-tertiary/40"
                        }`}
                      >
                        <div className="font-bold text-sm leading-tight">{p.name}</div>
                        <div className="text-[11px] font-mono-data opacity-90 mt-1">
                          Base: {formatPrice(p.priceInr, p.priceUsd)} / kg
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Quantity Slider & Input */}
                <div className="bg-primary-container/40 p-5 rounded-lg border border-primary-container">
                  <div className="flex flex-wrap gap-3 items-center justify-between mb-3">
                    <label htmlFor="calculator-quantity" className="text-xs font-mono-data text-primary-fixed uppercase tracking-wider">
                      2. Required Volume (kg)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        id="calculator-quantity"
                        type="number"
                        min="25"
                        max="10000"
                        step="25"
                        value={calcQuantityDraft}
                        onChange={(e) => {
                          const value = e.target.value;
                          setCalcQuantityDraft(value);
                          const quantity = Number(value);
                          if (value.trim() && quantity >= 25 && quantity <= 10000 && quantity % 25 === 0) setCalcQuantity(quantity);
                        }}
                        onBlur={() => { const value = normalizeQuantity(Number(calcQuantityDraft)); setCalcQuantity(value); setCalcQuantityDraft(String(value)); }}
                        onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); event.currentTarget.blur(); } }}
                        className="w-28 px-3 py-1.5 rounded bg-surface text-primary font-mono-data text-sm font-bold text-right outline-none focus:ring-2 focus:ring-tertiary"
                      />
                      <span className="font-mono-data text-xs text-primary-fixed">kg</span>
                    </div>
                  </div>

                  <input
                    type="range"
                    min="25"
                    max="10000"
                    step="25"
                    aria-label="Bulk order volume in kilograms"
                    aria-valuetext={`${calcQuantity} kilograms`}
                    value={calcQuantity}
                    onChange={(e) => setCalcQuantity(Number(e.target.value))}
                    className="w-full accent-tertiary cursor-pointer h-2 bg-primary-container rounded-lg"
                  />

                  {/* Volume Presets */}
                  <div className="flex flex-wrap gap-2 mt-4">
                    {[25, 100, 250, 500, 1000, 2500].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setCalcQuantity(preset)}
                        aria-pressed={calcQuantity === preset}
                        className={`text-xs px-2.5 py-1 rounded font-mono-data transition-colors ${
                          calcQuantity === preset
                            ? "bg-tertiary-fixed text-on-tertiary-fixed font-bold"
                            : "bg-primary-container text-on-primary/70 hover:text-on-primary"
                        }`}
                      >
                        {preset} kg
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tier Info Callout */}
                <div className="p-4 rounded bg-primary-container/30 border border-primary-container flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-tertiary-fixed">
                    <span className="material-symbols-outlined text-[18px]">verified</span>
                    <span className="font-semibold">{discountTier.label}</span>
                  </div>
                  {discountTier.pct > 0 && (
                    <span className="font-mono-data font-bold text-tertiary-fixed bg-tertiary/30 px-2 py-0.5 rounded">
                      Savings: {discountTier.pct}%
                    </span>
                  )}
                </div>
              </div>

              {/* Estimate Summary Box */}
              <div className="lg:col-span-5 bg-surface text-on-surface p-6 sm:p-8 rounded-xl border border-outline-variant shadow-xl">
                <span className="font-label-caps text-[11px] font-bold text-secondary uppercase tracking-wider block mb-1">
                  Commercial Quotation Estimate
                </span>
                <h3 className="font-display-lg text-2xl font-bold text-primary">
                  {activeCalcProduct.name}
                </h3>
                <p className="font-mono-data text-xs text-secondary mt-0.5">
                  Specification: {activeCalcProduct.assay}
                </p>

                <div className="my-6 space-y-3 font-mono-data text-xs border-y border-outline-variant/40 py-4">
                  <div className="flex justify-between">
                    <span className="text-on-surface-variant">Batch Volume:</span>
                    <span className="font-bold text-on-surface">{calcQuantity.toLocaleString()} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-on-surface-variant">Standard Drum Rate:</span>
                    <span className="text-on-surface">
                      {currency === "INR"
                        ? `₹${activeCalcProduct.priceInr.toLocaleString()}`
                        : `$${activeCalcProduct.priceUsd.toFixed(2)}`} / kg
                    </span>
                  </div>
                  <div className="flex justify-between text-emerald-800 font-semibold">
                    <span>Applied Volume Tier:</span>
                    <span>-{discountTier.pct}%</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-outline-variant/30">
                    <span className="font-semibold text-on-surface">Effective Unit Rate:</span>
                    <span className="font-bold text-primary text-sm">
                      {formatMoney(calcUnitPrice, currency)} / kg
                    </span>
                  </div>
                </div>

                <div className="mb-6">
                  <span className="font-label-caps text-[10px] text-on-surface-variant tracking-wider uppercase block">
                    Estimated Batch Subtotal ({currency})
                  </span>
                  <div aria-live="polite" aria-atomic="true"><motion.div key={`${calcTotalPrice}-${currency}`} initial={{ opacity: 0.5, y: reduceMotion ? 0 : 5 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.22 }} className="price-value font-display-lg text-3xl font-medium text-primary mt-1">{formatMoney(calcTotalPrice, currency)}</motion.div></div>
                  <span className="text-[11px] font-mono-data text-on-surface-variant block mt-1">
                    *Ex-factory works. Freight &amp; customs handled via preferred incoterm (FOB/CIF).
                  </span>
                </div>

                <div className="space-y-2">
                  <button
                    onClick={() => addToRfq(activeCalcProduct, "commercial", calcQuantity)}
                    className="w-full py-3 rounded bg-primary hover:bg-primary-container text-on-primary font-label-caps text-xs tracking-wider uppercase font-bold transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <span className="material-symbols-outlined text-[18px]">receipt_long</span>
                    <span>Add to cart &amp; continue</span>
                  </button>

                  <a
                    href={waLink(primaryWhatsapp, encodeURIComponent(
                      `Hello ${contact.companyName}, I used your volume calculator for ${calcQuantity} kg of ${activeCalcProduct.name} at effective rate ${
                        currency === "INR" ? `₹${calcUnitPrice.toFixed(0)}` : `$${calcUnitPrice.toFixed(2)}`
                      }/kg. Please confirm production availability. Factory: ${factoryLine}. ${deskLine} / ${contact.email}`
                    ))}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 rounded bg-emerald-800 hover:bg-emerald-700 text-emerald-50 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-[16px]">chat</span>
                    <span>Instant WhatsApp Proforma</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* Pharmacopoeial Quality & Laboratory Rigor Section */}
      <section id="quality" className="py-24 bg-surface-container-low border-t border-outline-variant/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Reveal className="max-w-2xl mb-16">
            <span className="font-label-caps text-xs text-secondary tracking-widest uppercase font-bold block mb-2">
              Analytical Certainty
            </span>
            <h2 className="font-headline-md text-3xl sm:text-4xl text-on-surface">
              Standardized Quality <span className="italic font-normal text-primary">Beyond The Monograph</span>
            </h2>
            <p className="text-sm text-on-surface-variant mt-3 leading-relaxed">
              Every batch undergoes a triple-gate testing regime: raw herb botanical identity, in-process extract purity, and finished powder chromatographic profiling.
            </p>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Reveal direction="right" className="bg-surface p-7 rounded-lg border border-outline-variant/50 shadow-sm flex flex-col justify-between hover:-translate-y-1 hover:shadow-lg transition-all">
              <div>
                <div className="w-12 h-12 rounded bg-tertiary/15 text-tertiary flex items-center justify-center mb-5">
                  <span className="material-symbols-outlined text-[26px]">monitoring</span>
                </div>
                <h3 className="font-display-lg text-xl font-bold text-on-surface mb-2">
                  High-Performance HPLC &amp; GC-MS
                </h3>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Fingerprint profiling against USP, Indian Pharmacopoeia (IP), and European Pharmacopoeia (Ph. Eur.) reference standards to verify active marker ratios.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-outline-variant/30 font-mono-data text-[11px] text-primary font-bold">
                Assay Accuracy &gt; 99.5%
              </div>
            </Reveal>

            <Reveal delay={0.1} direction="up" scale className="bg-surface p-7 rounded-lg border border-outline-variant/50 shadow-sm flex flex-col justify-between hover:-translate-y-1 hover:shadow-lg transition-all">
              <div>
                <div className="w-12 h-12 rounded bg-tertiary/15 text-tertiary flex items-center justify-center mb-5">
                  <span className="material-symbols-outlined text-[26px]">shield</span>
                </div>
                <h3 className="font-display-lg text-xl font-bold text-on-surface mb-2">
                  Heavy Metals by ICP-MS
                </h3>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Inductively Coupled Plasma Mass Spectrometry screening for Lead, Arsenic, Cadmium, and Mercury down to parts-per-billion (ppb) thresholds.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-outline-variant/30 font-mono-data text-[11px] text-primary font-bold">
                Complies with Prop 65 &amp; EU 1881
              </div>
            </Reveal>

            <Reveal delay={0.2} direction="left" className="bg-surface p-7 rounded-lg border border-outline-variant/50 shadow-sm flex flex-col justify-between hover:-translate-y-1 hover:shadow-lg transition-all">
              <div>
                <div className="w-12 h-12 rounded bg-tertiary/15 text-tertiary flex items-center justify-center mb-5">
                  <span className="material-symbols-outlined text-[26px]">sanitizer</span>
                </div>
                <h3 className="font-display-lg text-xl font-bold text-on-surface mb-2">
                  Zero ETO &amp; Zero Solvent Residue
                </h3>
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  We use pure water or food-grade ethanol and supercritical carbon dioxide. Absolutely zero Ethylene Oxide (ETO) sterilisation or chlorinated solvents.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-outline-variant/30 font-mono-data text-[11px] text-primary font-bold">
                100% Non-Irradiated Guaranteed
              </div>
            </Reveal>
          </div>

          {/* Pharmacopoeial Comparison Table */}
          <div className="mt-16 bg-surface rounded-xl border border-outline-variant/60 overflow-hidden shadow-sm">
            <div className="px-6 py-4 bg-surface-container-high border-b border-outline-variant/40 flex items-center justify-between">
              <span className="font-label-caps text-xs font-bold text-primary uppercase tracking-wider">
                Manglam Phytoo Protocol vs Conventional Commodity Traders
              </span>
              <span className="font-mono-data text-[11px] text-secondary">Updated 2025 Standard</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-outline-variant/40 bg-surface-container/50 font-mono-data text-on-surface">
                    <th className="py-3 px-6 font-bold">Parameter</th>
                    <th className="py-3 px-6 font-bold text-primary">Manglam Phytoo Standardized</th>
                    <th className="py-3 px-6 text-on-surface-variant">Generic Commodity Herbal Market</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-outline-variant/20 font-body-md">
                  <tr>
                    <td className="py-3.5 px-6 font-semibold">Active Phytochemical Assay</td>
                    <td className="py-3.5 px-6 font-mono-data text-emerald-800 font-bold bg-emerald-50/40">
                      Guaranteed HPLC with Withanolide / Alkaloid curve
                    </td>
                    <td className="py-3.5 px-6 text-on-surface-variant">Crude extract ratios (e.g. "10:1") without assay validation</td>
                  </tr>
                  <tr>
                    <td className="py-3.5 px-6 font-semibold">Botanical Provenance</td>
                    <td className="py-3.5 px-6 font-mono-data text-emerald-800 font-bold bg-emerald-50/40">
                      Geotagged wild-harvest cluster &amp; forest cooperative
                    </td>
                    <td className="py-3.5 px-6 text-on-surface-variant">Open mandi auctions with mixed geographic origins</td>
                  </tr>
                  <tr>
                    <td className="py-3.5 px-6 font-semibold">Heavy Metal Screen</td>
                    <td className="py-3.5 px-6 font-mono-data text-emerald-800 font-bold bg-emerald-50/40">
                      ICP-MS testing per individual production batch
                    </td>
                    <td className="py-3.5 px-6 text-on-surface-variant">Spot-tested yearly or self-certified</td>
                  </tr>
                  <tr>
                    <td className="py-3.5 px-6 font-semibold">Ethylene Oxide (ETO)</td>
                    <td className="py-3.5 px-6 font-mono-data text-emerald-800 font-bold bg-emerald-50/40">
                      Non-irradiated, zero ETO fumigation guarantee
                    </td>
                    <td className="py-3.5 px-6 text-on-surface-variant">Commonly treated with gas fumigation for microbial pass</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Pharma Client Testimonials */}
      <section className="py-24 bg-surface max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-label-caps text-xs text-secondary tracking-widest uppercase font-bold block mb-2">
            Trusted by Formulation Directors
          </span>
          <h2 className="font-headline-md text-3xl sm:text-4xl text-on-surface">
            What Formulators &amp; Procurement Heads Say
          </h2>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Reveal direction="right" className="p-7 rounded-xl bg-surface-container-low border border-outline-variant/60 flex flex-col justify-between hover:border-tertiary/50 transition-colors">
            <p className="text-sm text-on-surface leading-relaxed italic">
              &quot;Procuring Berberine HCl 60% and Gymnema 75% through Manglam Phytoo resolved our batch-to-batch color and assay deviation issues. The HPLC chromatograms sent with every shipment match our internal QC exactly.&quot;
            </p>
            <div className="mt-6 pt-4 border-t border-outline-variant/30 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-primary text-on-primary flex items-center justify-center font-bold text-xs">
                Dr
              </div>
              <div>
                <h5 className="font-bold text-xs text-on-surface">Dr. Ananya Sengupta</h5>
                <p className="text-[11px] font-mono-data text-secondary">VP Formulation, PhytoVeda Labs (Mumbai)</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.12} direction="up" scale className="p-7 rounded-xl bg-surface-container-low border border-outline-variant/60 flex flex-col justify-between hover:border-tertiary/50 transition-colors">
            <p className="text-sm text-on-surface leading-relaxed italic">
              &quot;Their Ashwagandha Water Extract 2.7% is genuinely 100% water soluble. We launched our adaptogenic ready-to-drink functional beverage without any particulate sedimentation or bitter aftertaste.&quot;
            </p>
            <div className="mt-6 pt-4 border-t border-outline-variant/30 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-tertiary text-on-tertiary flex items-center justify-center font-bold text-xs">
                MR
              </div>
              <div>
                <h5 className="font-bold text-xs text-on-surface">Marcus R. Vane</h5>
                <p className="text-[11px] font-mono-data text-secondary">Chief Science Officer, Kura Naturals (USA)</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.24} direction="left" className="p-7 rounded-xl bg-surface-container-low border border-outline-variant/60 flex flex-col justify-between hover:border-tertiary/50 transition-colors">
            <p className="text-sm text-on-surface leading-relaxed italic">
              &quot;Commercial logistics from Nhava Sheva to Europe went without a single customs delay. Full batch COA, allergen sheet, and non-GMO dossiers were supplied before the ship docked.&quot;
            </p>
            <div className="mt-6 pt-4 border-t border-outline-variant/30 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-secondary text-on-secondary flex items-center justify-center font-bold text-xs">
                HB
              </div>
              <div>
                <h5 className="font-bold text-xs text-on-surface">Helena Berglund</h5>
                <p className="text-[11px] font-mono-data text-secondary">Head of Raw Materials, Nordic Pharma AG</p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Final High-Conversion CTA & Direct Brief Section */}
      <section id="contact" className="py-24 bg-primary text-on-primary border-t-4 border-tertiary relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left text */}
            <Reveal direction="right" distance={40} className="lg:col-span-6 space-y-6">
              <span className="font-label-caps text-xs text-tertiary-fixed font-bold tracking-[0.25em] uppercase block">
                Direct Mill &amp; Extraction Plant Contact
              </span>
              <h2 className="font-display-lg text-4xl sm:text-5xl text-on-primary leading-tight">
                Lock In Your Next Batch Allocation Today.
              </h2>
              <p className="text-on-primary/80 text-base leading-relaxed">
                Connect directly with our phytochemical extraction engineers and commercial supply team. Request formal proformas, custom assay formulation, or immediate air-freight dispatch.
              </p>

              <div className="space-y-4 pt-2 font-mono-data text-xs text-on-primary/90">
                <div className="flex items-start gap-3">
                  <span className="mt-0.5 w-8 h-8 shrink-0 rounded bg-primary-container flex items-center justify-center text-tertiary-fixed">
                    <span className="material-symbols-outlined text-[18px]">location_on</span>
                  </span>
                  <address className="not-italic leading-relaxed">
                    <span className="block font-bold text-tertiary-fixed font-body-md text-sm">{contact.companyName}</span>
                    {contact.addressLine1 && <span className="block mt-0.5">{contact.addressLine1}</span>}
                    {contact.addressLine2 && <span className="block">{contact.addressLine2}</span>}
                    <span className="block font-semibold">{contact.city}{contact.postalCode && ` (${contact.postalCode})`}</span>
                    {contact.region && <span className="block">{contact.region}</span>}
                  </address>
                </div>
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded bg-primary-container flex items-center justify-center text-tertiary-fixed">
                    <span className="material-symbols-outlined text-[18px]">mail</span>
                  </span>
                  <a href={`mailto:${contact.email}`} className="hover:text-tertiary-fixed underline break-all">
                    {contact.email}
                  </a>
                </div>
                {(contact.desk1 || contact.desk2) && (
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 w-8 h-8 shrink-0 rounded bg-primary-container flex items-center justify-center text-tertiary-fixed">
                      <span className="material-symbols-outlined text-[18px]">call</span>
                    </span>
                    <div className="leading-relaxed">
                      <span className="block text-[10px] uppercase tracking-wider text-tertiary-fixed font-semibold mb-0.5">Desk Numbers</span>
                      {contact.desk1 && <a href={telLink(contact.desk1)} className="block hover:text-tertiary-fixed">Desk 1: {formatPhone(contact.desk1)}</a>}
                      {contact.desk2 && <a href={telLink(contact.desk2)} className="block hover:text-tertiary-fixed">Desk 2: {formatPhone(contact.desk2)}</a>}
                    </div>
                  </div>
                )}
                {(contact.whatsapp1 || contact.whatsapp2) && (
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 w-8 h-8 shrink-0 rounded bg-emerald-800 flex items-center justify-center text-emerald-100">
                      <span className="material-symbols-outlined text-[18px]">chat</span>
                    </span>
                    <div className="leading-relaxed">
                      <span className="block text-[10px] uppercase tracking-wider text-tertiary-fixed font-semibold mb-0.5">WhatsApp Numbers</span>
                      {contact.whatsapp1 && <a href={waLink(contact.whatsapp1, whatsappMessage)} target="_blank" rel="noopener noreferrer" className="block hover:text-tertiary-fixed">WhatsApp 1: {formatPhone(contact.whatsapp1)}</a>}
                      {contact.whatsapp2 && <a href={waLink(contact.whatsapp2, whatsappMessage)} target="_blank" rel="noopener noreferrer" className="block hover:text-tertiary-fixed">WhatsApp 2: {formatPhone(contact.whatsapp2)}</a>}
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-4 flex flex-wrap gap-3">
                {contact.whatsapp1 && (
                  <a
                    href={waLink(contact.whatsapp1, whatsappMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 rounded bg-emerald-800 text-emerald-100 hover:bg-emerald-700 text-xs font-bold uppercase tracking-wider flex items-center gap-2 font-label-caps transition-colors"
                  >
                    <span className="material-symbols-outlined text-[18px]">chat</span>
                    <span>WhatsApp 1 &bull; {formatPhone(contact.whatsapp1).replace("+91 ", "")}</span>
                  </a>
                )}
                {contact.whatsapp2 && (
                  <a
                    href={waLink(contact.whatsapp2, whatsappMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 rounded border border-emerald-500/50 text-emerald-100 hover:bg-emerald-800/60 text-xs font-bold uppercase tracking-wider flex items-center gap-2 font-label-caps transition-colors"
                  >
                    <span className="material-symbols-outlined text-[18px]">chat</span>
                    <span>WhatsApp 2 &bull; {formatPhone(contact.whatsapp2).replace("+91 ", "")}</span>
                  </a>
                )}
              </div>
            </Reveal>

            {/* Right Quick Inquiry Form */}
            <Reveal delay={0.12} direction="left" distance={40} className="lg:col-span-6 bg-surface text-on-surface p-6 sm:p-10 rounded-2xl shadow-2xl border border-outline-variant">
              <h3 className="font-display-lg text-2xl font-bold text-primary mb-1">
                Commercial Brief &amp; Sample Request
              </h3>
              <p className="text-xs text-on-surface-variant mb-6">
                Prepare a downloadable ingredient brief to share with your verified sales contact. No details are sent automatically.
              </p>

              {inquirySuccess ? (
                <div role="status" className="p-8 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-900 text-center space-y-3">
                  <span className="material-symbols-outlined text-4xl text-emerald-700">task_alt</span>
                  <h4 className="font-display-lg text-xl font-bold">Your brief is ready</h4>
                  <p className="text-xs">
                    Your download contains your contact details and requirements. Share it with your sales representative; it has not been sent by this website.
                  </p>
                  <button type="button" onClick={() => setInquirySuccess(false)} className="min-h-10 text-xs font-semibold underline underline-offset-4">Edit or download again</button>
                </div>
              ) : (
                <form onSubmit={handleQuickInquiry} className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="inquiry-name" className="block font-semibold text-on-surface mb-1">Full Name *</label>
                      <input
                        id="inquiry-name"
                        autoComplete="name"
                        required
                        type="text"
                        value={inquiryName}
                        onChange={(e) => setInquiryName(e.target.value)}
                        placeholder="Dr. Rajesh / Formulator"
                        className="w-full p-2.5 rounded border border-outline-variant bg-surface-container-low text-on-surface focus:border-primary outline-none"
                      />
                    </div>
                    <div>
                      <label htmlFor="inquiry-company" className="block font-semibold text-on-surface mb-1">Company / Laboratory *</label>
                      <input
                        id="inquiry-company"
                        autoComplete="organization"
                        required
                        type="text"
                        value={inquiryCompany}
                        onChange={(e) => setInquiryCompany(e.target.value)}
                        placeholder="Pharma / Nutraceutical Ltd"
                        className="w-full p-2.5 rounded border border-outline-variant bg-surface-container-low text-on-surface focus:border-primary outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="inquiry-email" className="block font-semibold text-on-surface mb-1">Corporate Email *</label>
                      <input
                        id="inquiry-email"
                        autoComplete="email"
                        required
                        type="email"
                        value={inquiryEmail}
                        onChange={(e) => setInquiryEmail(e.target.value)}
                        placeholder="procurement@company.com"
                        className="w-full p-2.5 rounded border border-outline-variant bg-surface-container-low text-on-surface focus:border-primary outline-none"
                      />
                    </div>
                    <div>
                      <label htmlFor="inquiry-phone" className="block font-semibold text-on-surface mb-1">Phone / WhatsApp</label>
                      <input
                        id="inquiry-phone"
                        autoComplete="tel"
                        type="tel"
                        value={inquiryPhone}
                        onChange={(e) => setInquiryPhone(e.target.value)}
                        placeholder="+91 / +1 (country code)"
                        className="w-full p-2.5 rounded border border-outline-variant bg-surface-container-low text-on-surface focus:border-primary outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="inquiry-notes" className="block font-semibold text-on-surface mb-1">
                      Required Products &amp; Volumes *
                    </label>
                    <textarea
                      id="inquiry-notes"
                      required
                      rows={3}
                      value={inquiryNotes}
                      onChange={(e) => setInquiryNotes(e.target.value)}
                      placeholder="e.g. Gymnema extract 75% (100 kg), Berberine HCl 60% (50 kg), plus 50 g sample kit for R&D..."
                      className="w-full p-2.5 rounded border border-outline-variant bg-surface-container-low text-on-surface focus:border-primary outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded bg-primary hover:bg-primary-container text-on-primary font-label-caps text-xs tracking-wider uppercase font-bold transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <span className="material-symbols-outlined text-[18px]" aria-hidden="true">download</span>
                    <span>Download Commercial Brief</span>
                  </button>
                </form>
              )}
            </Reveal>
          </div>
        </div>
      </section>

      </main>

      {/* Rich B2B Footer from Design B */}
      <footer className="w-full bg-primary text-on-primary py-16 border-t-4 border-tertiary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-primary-container">
            {/* Col 1 */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded bg-tertiary text-on-tertiary flex items-center justify-center font-display-lg font-bold">
                  M
                </div>
                <span className="font-display-lg text-lg font-bold text-on-primary">
                  Manglam Phytoo
                </span>
              </div>
              <p className="text-xs text-on-primary/70 leading-relaxed">
                Pioneering the forest-to-extract standardization protocol for global phytopharmaceutical manufacturers, clinical nutraceuticals, and clean-label botanicals.
              </p>
              <div className="flex items-center gap-2 font-mono-data text-[11px] text-tertiary-fixed">
                <span className="material-symbols-outlined text-[16px]">verified_user</span>
                <span>GMP &bull; ISO 9001:2015 &bull; AYUSH Certified</span>
              </div>
            </div>

            {/* Col 2 */}
            <div>
              <h5 className="font-label-caps text-xs font-bold text-tertiary-fixed tracking-wider uppercase mb-4">
                Core Phytochemicals
              </h5>
              <ul className="space-y-2 text-xs text-on-primary/75">
                {PRODUCTS.map((p) => (
                  <li key={p.id}>
                    <a href="#products" className="hover:text-tertiary-fixed transition-colors">
                      {p.name} ({formatPrice(p.priceInr, p.priceUsd)}/kg)
                    </a>
                  </li>
                ))}
                <li>
                  <a href="#products" className="hover:text-tertiary-fixed transition-colors">
                    Custom Botanical Assay R&amp;D
                  </a>
                </li>
              </ul>
            </div>

            {/* Col 3 */}
            <div>
              <h5 className="font-label-caps text-xs font-bold text-tertiary-fixed tracking-wider uppercase mb-4">
                Quality &amp; Compliance
              </h5>
              <ul className="space-y-2 text-xs text-on-primary/75">
                <li>
                  <a href="#quality" className="hover:text-tertiary-fixed transition-colors">
                    HPLC Fingerprint Monographs
                  </a>
                </li>
                <li>
                  <a href="#quality" className="hover:text-tertiary-fixed transition-colors">
                    ICP-MS Heavy Metal Testing
                  </a>
                </li>
                <li>
                  <a href="#process" className="hover:text-tertiary-fixed transition-colors">
                    Supercritical CO2 Extraction
                  </a>
                </li>
                <li>
                  <a href="#process" className="hover:text-tertiary-fixed transition-colors">
                    Batch Traceability QR System
                  </a>
                </li>
                <li>
                  <a href="#quality" className="hover:text-tertiary-fixed transition-colors">
                    Zero Ethylene Oxide (ETO) Standard
                  </a>
                </li>
              </ul>
            </div>

            {/* Col 4 */}
            <div>
              <h5 className="font-label-caps text-xs font-bold text-tertiary-fixed tracking-wider uppercase mb-4">
                Factory &amp; Direct Contact
              </h5>
              <address className="not-italic text-xs text-on-primary/75 leading-relaxed space-y-2">
                <p>
                  <span className="block font-bold text-tertiary-fixed">{contact.companyName}</span>
                  {contact.addressLine1 && <>{contact.addressLine1.replace(/^Factory at\s*/i, "")}<br /></>}
                  {contact.addressLine2 && <>{contact.addressLine2},<br /></>}
                  <span className="font-semibold text-tertiary-fixed">{contact.city}{contact.postalCode && ` (${contact.postalCode})`}</span><br />
                  {contact.region}
                </p>
                {(contact.desk1 || contact.desk2) && (
                  <p className="space-y-0.5">
                    {contact.desk1 && <a href={telLink(contact.desk1)} className="block hover:text-tertiary-fixed"><span className="material-symbols-outlined text-[14px] align-middle">call</span> Desk 1: {formatPhone(contact.desk1)}</a>}
                    {contact.desk2 && <a href={telLink(contact.desk2)} className="block hover:text-tertiary-fixed"><span className="material-symbols-outlined text-[14px] align-middle">call</span> Desk 2: {formatPhone(contact.desk2)}</a>}
                  </p>
                )}
                {(contact.whatsapp1 || contact.whatsapp2) && (
                  <p className="space-y-0.5">
                    {contact.whatsapp1 && <a href={waLink(contact.whatsapp1, whatsappMessage)} target="_blank" rel="noopener noreferrer" className="block hover:text-tertiary-fixed"><span className="material-symbols-outlined text-[14px] align-middle">chat</span> WhatsApp 1: {formatPhone(contact.whatsapp1)}</a>}
                    {contact.whatsapp2 && <a href={waLink(contact.whatsapp2, whatsappMessage)} target="_blank" rel="noopener noreferrer" className="block hover:text-tertiary-fixed"><span className="material-symbols-outlined text-[14px] align-middle">chat</span> WhatsApp 2: {formatPhone(contact.whatsapp2)}</a>}
                  </p>
                )}
                <p>
                  <a href={`mailto:${contact.email}`} className="hover:text-tertiary-fixed break-all">
                    <span className="material-symbols-outlined text-[14px] align-middle">mail</span> {contact.email}
                  </a>
                </p>
              </address>
              <div className="mt-3 p-3 rounded bg-primary-container text-xs font-mono-data text-primary-fixed border border-primary-container">
                <div>Hours: {contact.hours}</div>
                <div className="mt-1 text-tertiary-fixed">Dispatch Hub: Active</div>
              </div>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-on-primary/60">
            <p>
              &copy; {new Date().getFullYear()} Manglam Phytoo Exploration. All rights reserved. Exclusively for B2B pharmaceutical, nutraceutical, and research use.
            </p>
            <div className="flex flex-wrap items-center gap-4 sm:gap-6">
              <a href="#" className="hover:text-on-primary">Privacy Policy</a>
              <a href="#" className="hover:text-on-primary">Terms of Supply</a>
              <a href="#" className="hover:text-on-primary">Pharmacopoeial Monograph Disclaimer</a>
              <button type="button" onClick={() => setAdminOpen(true)} className="inline-flex items-center gap-1.5 rounded border border-tertiary/40 px-3 py-1.5 text-tertiary-fixed hover:bg-tertiary/10 transition-colors">
                <Settings2 size={11} aria-hidden="true" /> Admin
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* COA & Specification Sheet Modal */}
      <AnimatePresence>
      {selectedProductForCoa && (
        <Dialog key="product-specifications" labelId="specification-heading" descriptionId="specification-note" onClose={() => setSelectedProductForCoa(null)}>
          <div className="p-5 sm:p-8">
            <div className="flex items-start justify-between border-b border-outline-variant/40 pb-4">
              <div>
                <span className="font-label-caps text-[10px] text-secondary font-bold uppercase tracking-widest">
                  Manglam Phytoo Ingredient Portfolio
                </span>
                <h3 id="specification-heading" tabIndex={-1} data-dialog-heading className="font-display-lg text-2xl font-medium text-primary mt-0.5 outline-none">
                  {selectedProductForCoa.name}
                </h3>
                <p className="font-mono-data text-xs text-secondary mt-1">
                  {selectedProductForCoa.botanical}
                </p>
              </div>
              <button
                onClick={() => setSelectedProductForCoa(null)}
                className="p-1.5 rounded-full hover:bg-surface-container-high text-on-surface-variant"
                aria-label="Close COA modal"
              >
                <span className="material-symbols-outlined text-[22px]">close</span>
              </button>
            </div>
            <p id="specification-note" className="mt-5 text-xs leading-6 text-secondary">Illustrative catalog specifications, not a released batch certificate. Confirm the specifications with a current, signed supplier COA before procurement.</p>

            <div className="my-6 space-y-4 font-mono-data text-xs">
              <div className="p-3 rounded bg-surface-container-low border border-outline-variant/40 grid grid-cols-2 gap-3">
                <div>
                  <span className="text-on-surface-variant block text-[11px]">Plant Part:</span>
                  <span className="font-bold text-on-surface">{selectedProductForCoa.part}</span>
                </div>
                <div>
                  <span className="text-on-surface-variant block text-[11px]">Documentation:</span>
                  <span className="font-bold text-on-surface">Request current batch COA</span>
                </div>
                <div>
                  <span className="text-on-surface-variant block text-[11px]">Factory Drum Rate:</span>
                  <span className="font-bold text-primary">{formatPrice(selectedProductForCoa.priceInr, selectedProductForCoa.priceUsd)} / kg</span>
                </div>
                <div>
                  <span className="text-on-surface-variant block text-[11px]">Storage Condition:</span>
                  <span className="text-on-surface">Store cool (&lt;25°C), dry place</span>
                </div>
              </div>

              <div className="border border-outline-variant/40 rounded overflow-x-auto">
                <table className="w-full min-w-80 text-left">
                  <thead className="bg-surface-container font-bold border-b border-outline-variant/40">
                    <tr>
                      <th className="p-2.5">Test Parameter</th>
                      <th className="p-2.5">Specification</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-outline-variant/20">
                    <tr>
                      <td className="p-2.5 font-semibold">Active Marker Assay</td>
                      <td className="p-2.5">{selectedProductForCoa.assay}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold">Appearance &amp; Color</td>
                      <td className="p-2.5">{selectedProductForCoa.appearance}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold">Loss on Drying</td>
                      <td className="p-2.5">{selectedProductForCoa.lossOnDrying}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold">Heavy Metals (ICP-MS)</td>
                      <td className="p-2.5">{selectedProductForCoa.heavyMetals}</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-semibold">Microbiological Limit</td>
                      <td className="p-2.5">{selectedProductForCoa.microbial}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-outline-variant/40">
              <span className="text-xs font-mono-data text-emerald-800 flex items-center gap-1 font-semibold">
                <span className="material-symbols-outlined text-[16px]" aria-hidden="true">description</span>
                Confirm all specifications before ordering
              </span>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    addToRfq(selectedProductForCoa, "sample", 1);
                    setSelectedProductForCoa(null);
                  }}
                  className="px-4 py-2 rounded bg-primary text-on-primary text-xs font-bold font-label-caps uppercase"
                >
                  Request {SAMPLE_GRAMS} g Sample{samplePrice(selectedProductForCoa, currency) !== null && ` · ${formatMoney(samplePrice(selectedProductForCoa, currency)!, currency)}`}
                </button>
              </div>
            </div>
          </div>
        </Dialog>
      )}
      </AnimatePresence>

      <BackToTop />
      <AdminPanel open={adminOpen} config={config} onClose={() => setAdminOpen(false)} onApply={applyConfig} />
      <CheckoutDrawer
        open={rfqDrawerOpen}
        items={rfqItems}
        currency={currency}
        salesNumbers={contact.salesWhatsapp}
        salesEmails={contact.salesEmails}
        onClose={() => setRfqDrawerOpen(false)}
        onRemove={removeFromRfq}
        onQuantityChange={updateRfqQuantity}
        onCurrencyChange={setCurrency}
        onComplete={() => setRfqItems([])}
      />
    </div>
  );
}
