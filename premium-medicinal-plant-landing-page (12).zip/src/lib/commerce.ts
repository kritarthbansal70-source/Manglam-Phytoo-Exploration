export type Currency = "INR" | "USD";

export interface Product {
  id: string;
  name: string;
  botanical: string;
  part: string;
  assay: string;
  standard: string;
  priceInr: number;
  priceUsd: number;
  stockKg: number;
  batchNo: string;
  appearance: string;
  solubility: string;
  lossOnDrying: string;
  heavyMetals: string;
  microbial: string;
  applications: string[];
  description: string;
  image: string;
  popular?: boolean;
  /** Price of one analytical sample kit in INR (see SAMPLE_GRAMS). */
  samplePriceInr?: number;
  /** Optional USD price for one sample kit; derived from INR when absent. */
  samplePriceUsd?: number;
}

/** Weight of one sample kit in grams. */
export const SAMPLE_GRAMS = 50;
/** Fallback INR→USD rate used only for sample kits without an explicit USD price. */
export const SAMPLE_USD_RATE = 1 / 96;

export function samplePrice(product: Product, currency: Currency): number | null {
  const inr = product.samplePriceInr;
  if (!inr || inr <= 0) return null;
  if (currency === "INR") return inr;
  if (product.samplePriceUsd && product.samplePriceUsd > 0) return product.samplePriceUsd;
  return Math.round(inr * SAMPLE_USD_RATE * 100) / 100;
}

export interface CartItem {
  product: Product;
  qty: number;
  type: "sample" | "commercial";
}

export interface DeliveryAddress {
  fullName: string;
  company: string;
  email: string;
  phone: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  instructions: string;
}

export type AddressErrors = Partial<Record<keyof DeliveryAddress, string>>;

export const EMPTY_ADDRESS: DeliveryAddress = {
  fullName: "", company: "", email: "", phone: "", addressLine1: "",
  addressLine2: "", city: "", region: "", postalCode: "", country: "India", instructions: "",
};

export function normalizeQuantity(value: number, type: CartItem["type"] = "commercial") {
  const step = type === "sample" ? 1 : 25;
  const max = type === "sample" ? 10 : 10000;
  return Math.max(step, Math.min(max, Math.round((Number.isFinite(value) ? value : step) / step) * step));
}

export function getVolumeTier(quantity: number) {
  if (quantity >= 1000) return { pct: 15, label: "Tier 4: Enterprise Pallet (15% Off)" };
  if (quantity >= 500) return { pct: 10, label: "Tier 3: Commercial Wholesale (10% Off)" };
  if (quantity >= 100) return { pct: 5, label: "Tier 2: Production Batch (5% Off)" };
  return { pct: 0, label: "Tier 1: Standard Drum MOQ (Factory Rate)" };
}

export function linePricing(item: CartItem, currency: Currency) {
  if (item.type === "sample") {
    const unit = samplePrice(item.product, currency);
    if (unit === null) return { unit: 0, total: 0, savings: 0, discount: 0, priced: false };
    const unitMinor = Math.round(unit * 100);
    return { unit: unitMinor / 100, total: (unitMinor * item.qty) / 100, savings: 0, discount: 0, priced: true };
  }
  const baseMinor = Math.round((currency === "INR" ? item.product.priceInr : item.product.priceUsd) * 100);
  const discount = getVolumeTier(item.qty).pct;
  // Round at the unit level so the displayed rate always reconciles with the total.
  const unitMinor = Math.round(baseMinor * (1 - discount / 100));
  return {
    unit: unitMinor / 100,
    total: (unitMinor * item.qty) / 100,
    savings: ((baseMinor - unitMinor) * item.qty) / 100,
    discount,
    priced: true,
  };
}

export function cartTotals(items: CartItem[], currency: Currency) {
  const totals = items.reduce((sum, item) => {
    const line = linePricing(item, currency);
    return { total: sum.total + Math.round(line.total * 100), savings: sum.savings + Math.round(line.savings * 100) };
  }, { total: 0, savings: 0 });
  return { total: totals.total / 100, savings: totals.savings / 100 };
}

export function formatMoney(value: number, currency: Currency) {
  return new Intl.NumberFormat(currency === "INR" ? "en-IN" : "en-US", {
    style: "currency", currency, minimumFractionDigits: currency === "USD" || value % 1 !== 0 ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(value);
}

export function validateAddress(address: DeliveryAddress): AddressErrors {
  const errors: AddressErrors = {};
  if (address.fullName.trim().length < 2) errors.fullName = "Enter the recipient's full name.";
  if (address.company.trim().length < 2) errors.company = "Enter your company or laboratory name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(address.email.trim())) errors.email = "Enter a valid email address.";
  const digits = address.phone.replace(/\D/g, "");
  if (!/^[+()\d\s.\-]+$/.test(address.phone.trim()) || digits.length < 7 || digits.length > 15) errors.phone = "Enter a valid phone number, including country code.";
  if (address.addressLine1.trim().length < 5) errors.addressLine1 = "Enter a street address and building number.";
  if (address.city.trim().length < 2) errors.city = "Enter your city.";
  if (address.region.trim().length < 2) errors.region = "Enter your state, province, or region.";
  if (address.country.trim().length < 2) errors.country = "Enter your delivery country.";

  const country = address.country.trim().toLowerCase();
  const code = address.postalCode.trim();
  if (country === "india" || country === "in") {
    if (!/^[1-9]\d{5}$/.test(code)) errors.postalCode = "Enter a valid 6-digit Indian PIN code.";
  } else if (["united states", "united states of america", "us", "usa"].includes(country)) {
    if (!/^\d{5}(-\d{4})?$/.test(code)) errors.postalCode = "Enter a valid ZIP code (e.g. 10001).";
  } else if (!/^[\p{L}\p{N}\s\-/]{2,14}$/u.test(code)) {
    errors.postalCode = "Enter a postal code, or N/A if your country has none.";
  }
  return errors;
}

const CART_KEY = "manglam-cart-v1";

export function loadCart(products: Product[]): CartItem[] {
  try {
    const saved: unknown = JSON.parse(localStorage.getItem(CART_KEY) ?? "[]");
    if (!Array.isArray(saved)) return [];
    const result: CartItem[] = [];
    saved.slice(0, 20).forEach((entry) => {
      if (!entry || typeof entry !== "object") return;
      const product = products.find((p) => p.id === entry.id);
      if (!product || !["sample", "commercial"].includes(entry.type) || typeof entry.qty !== "number") return;
      const existing = result.find((item) => item.product.id === product.id && item.type === entry.type);
      if (existing) existing.qty = normalizeQuantity(existing.qty + entry.qty, entry.type);
      else result.push({ product, type: entry.type, qty: normalizeQuantity(entry.qty, entry.type) });
    });
    return result;
  } catch { return []; }
}

export function persistCart(items: CartItem[]) {
  try {
    // Keep only catalog selections in storage, never delivery or contact information.
    localStorage.setItem(CART_KEY, JSON.stringify(items.map((item) => ({ id: item.product.id, qty: item.qty, type: item.type }))));
  } catch { /* The cart remains usable when browser storage is unavailable. */ }
}

export function downloadText(filename: string, contents: string) {
  const url = URL.createObjectURL(new Blob([contents], { type: "text/plain;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}