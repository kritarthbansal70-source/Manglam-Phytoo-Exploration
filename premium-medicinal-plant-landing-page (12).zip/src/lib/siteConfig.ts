import type { Product } from "./commerce";
import { IMAGES } from "./images";

export interface ContactInfo {
  companyName: string;
  desk1: string;
  desk2: string;
  whatsapp1: string;
  whatsapp2: string;
  email: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  postalCode: string;
  region: string;
  hours: string;
  /** WhatsApp numbers that receive order details after checkout. */
  salesWhatsapp: string[];
  /** Email addresses that receive order details after checkout. */
  salesEmails: string[];
}

export interface SiteConfig {
  products: Product[];
  contact: ContactInfo;
  updatedAt: string;
}

export const DEFAULT_PRODUCTS: Product[] = [
  {
    id: "gymnema-75",
    name: "Gymnema Extract 75%",
    botanical: "Gymnema sylvestre",
    part: "Foliage / Dried Leaves",
    assay: "≥ 75.0% Gymnemic Acids",
    standard: "Gravimetric / Validated HPLC",
    priceInr: 3400,
    priceUsd: 35.42,
    stockKg: 3200,
    batchNo: "MPE-GYM-75-25B",
    appearance: "Fine greenish-brown homogeneous powder",
    solubility: "Soluble in hydro-alcoholic mixtures",
    lossOnDrying: "≤ 5.0% w/w",
    heavyMetals: "Pb < 1.5 ppm, As < 0.8 ppm, Cd < 0.2 ppm, Hg < 0.05 ppm",
    microbial: "TPC < 3,000 cfu/g, E. coli & Salmonella Absent",
    applications: ["Metabolic Syndrome", "Glycemic Modulation", "Sugar Receptor Antagonism", "Anti-Diabetic Formulations"],
    description: "Standardized high-titer gymnemic acids extract ethically gathered from Central Indian dry deciduous tracts.",
    image: IMAGES.gymnema,
    popular: true,
    samplePriceInr: 300,
  },
  {
    id: "berberine-60",
    name: "Berberine HCl 60%+",
    botanical: "Berberis aristata (Daruharidra)",
    part: "Root & Stem Bark",
    assay: "≥ 60.0% Berberine Hydrochloride (HPLC)",
    standard: "USP / Ph. Eur. Monograph Matched",
    priceInr: 4000,
    priceUsd: 41.67,
    stockKg: 2850,
    batchNo: "MPE-BER-60-25D",
    appearance: "Vibrant yellow crystalline micro-powder",
    solubility: "Sparingly soluble in water, soluble in hot water",
    lossOnDrying: "≤ 6.0% w/w",
    heavyMetals: "Total heavy metals < 10 ppm (ICP-MS)",
    microbial: "Yeast & Mold < 50 cfu/g, Pathogens Negative",
    applications: ["AMPK Activator", "Cardiometabolic Health", "Microbiome Equilibrium", "Lipid Profile Management"],
    description: "Pharma-grade isoquinoline alkaloid isolated via closed-loop extraction.",
    image: IMAGES.berberine,
    popular: true,
    samplePriceInr: 300,
  },
  {
    id: "ashwagandha-water-27",
    name: "Ashwagandha Water Extract 2.7%",
    botanical: "Withania somnifera",
    part: "Roots (Nagori Cultivar)",
    assay: "≥ 2.70% Total Withanolides",
    standard: "HPLC with Withaferin-A verification",
    priceInr: 325,
    priceUsd: 3.39,
    stockKg: 8500,
    batchNo: "MPE-ASH-W27-25E",
    appearance: "Free-flowing light tan powder",
    solubility: "100% Cold Water Soluble, Clear in Solution",
    lossOnDrying: "≤ 4.5% w/w",
    heavyMetals: "USP <2232> compliant, Pb < 1.0 ppm",
    microbial: "Total Plate Count < 1,000 cfu/g",
    applications: ["Stress & Cortisol Normalization", "Adaptogenic Beverages", "Gummies & Functional Foods", "Cognitive Nootropics"],
    description: "Clean aqueous root extraction preserving native full-spectrum withanolide glycosides.",
    image: IMAGES.ashwagandha,
    popular: false,
    samplePriceInr: 150,
  },
  {
    id: "ashwagandha-water-5",
    name: "Ashwagandha Water Extract 5%+",
    botanical: "Withania somnifera",
    part: "Roots (Nagori Cultivar)",
    assay: "≥ 5.0% Total Withanolides",
    standard: "HPLC with Withaferin-A verification",
    priceInr: 700,
    priceUsd: 7.3,
    stockKg: 5200,
    batchNo: "MPE-ASH-W50-25F",
    appearance: "Free-flowing light brown powder",
    solubility: "100% Cold Water Soluble, Clear in Solution",
    lossOnDrying: "≤ 4.5% w/w",
    heavyMetals: "USP <2232> compliant, Pb < 1.0 ppm",
    microbial: "Total Plate Count < 1,000 cfu/g",
    applications: ["High-Potency Adaptogen", "Clinical-Dose Capsules", "Sports Recovery", "Sleep & Stress Formulas"],
    description: "High-potency aqueous root extract concentrated to 5%+ total withanolides.",
    image: IMAGES.ashwagandha5,
    popular: true,
    samplePriceInr: 150,
  },
  {
    id: "methidana-50",
    name: "Methidana Extract 50%+",
    botanical: "Trigonella foenum-graecum",
    part: "Sun-cured Seeds",
    assay: "≥ 50.0% Total Steroidal Saponins",
    standard: "UV-Vis Spectrophotometry / HPLC",
    priceInr: 950,
    priceUsd: 10.0,
    stockKg: 4600,
    batchNo: "MPE-MET-50-25A",
    appearance: "Fine off-white to cream powder",
    solubility: "Partially soluble in water, dispersible",
    lossOnDrying: "≤ 5.0% w/w",
    heavyMetals: "Meets EU Commission Regulation 1881/2006",
    microbial: "Total Aerobic Count < 5,000 cfu/g",
    applications: ["Insulin Mimetic Nutrition", "Lipid Metabolism", "Maternal Lactation Formulas", "Male Testosterone Support"],
    description: "Defatted fenugreek seed extract enriched for furostanolic saponins and 4-hydroxyisoleucine.",
    image: IMAGES.methidana,
    popular: false,
    samplePriceInr: 150,
  },
];

export const DEFAULT_CONTACT: ContactInfo = {
  companyName: "Manglam Phytoo EXPLORATION",
  desk1: "6395535399",
  desk2: "9991065301",
  whatsapp1: "9837008038",
  whatsapp2: "9991065301",
  email: "mangalamphyto@gmail.com",
  addressLine1: "Factory at Village – Basai,",
  addressLine2: "Kashipur Road, NH 309",
  city: "RAMNAGAR",
  postalCode: "244715",
  region: "Nainital, Uttarakhand",
  hours: "Mon – Sat, 09:00 – 19:00 IST",
  salesWhatsapp: ["9193350312", "9837008038", "9991065301"],
  salesEmails: ["kritarthbansal70@gmail.com", "deepakrmr2011@gmail.com", "manglamphyto@gmail.com"],
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export function isEmail(value: string) {
  return EMAIL_RE.test(value.trim());
}

/** mailto: link to every sales address with the order pre-filled. */
export function orderMailto(recipients: string[], subject: string, body: string) {
  const to = recipients.map((e) => e.trim()).filter(isEmail).join(",");
  return `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export const DEFAULT_CONFIG: SiteConfig = {
  products: DEFAULT_PRODUCTS,
  contact: DEFAULT_CONTACT,
  updatedAt: "",
};

const CONFIG_KEY = "manglam-site-config-v1";
const PIN_KEY = "manglam-admin-pin-v1";
export const DEFAULT_ADMIN_PIN = "2024";

/** Strip everything except digits so tel:/wa.me links are always valid. */
export function digitsOnly(value: string) {
  return value.replace(/\D/g, "");
}

/** Add India country code when a 10-digit national number is entered. */
export function toE164(value: string) {
  const d = digitsOnly(value);
  if (d.length === 10) return `91${d}`;
  return d;
}

/** Pretty print as +91 98370 08038 for 10/12-digit Indian numbers. */
export function formatPhone(value: string) {
  const d = toE164(value);
  if (d.length === 12 && d.startsWith("91")) return `+91 ${d.slice(2, 7)} ${d.slice(7)}`;
  return d ? `+${d}` : "";
}

export function waLink(number: string, message: string) {
  return `https://wa.me/${toE164(number)}?text=${message}`;
}

export function telLink(number: string) {
  return `tel:+${toE164(number)}`;
}

function isProduct(entry: unknown): entry is Product {
  if (!entry || typeof entry !== "object") return false;
  const p = entry as Record<string, unknown>;
  return typeof p.id === "string" && typeof p.name === "string" && typeof p.priceInr === "number" && typeof p.priceUsd === "number";
}

export function sanitizeConfig(raw: unknown): SiteConfig | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Partial<SiteConfig>;
  if (!Array.isArray(r.products)) return null;
  const products = r.products.filter(isProduct).map((p) => ({
    ...p,
    applications: Array.isArray(p.applications) ? p.applications.filter((a) => typeof a === "string") : [],
    stockKg: typeof p.stockKg === "number" ? p.stockKg : 0,
    popular: !!p.popular,
    image: typeof p.image === "string" && p.image ? p.image : IMAGES.gymnema,
    description: typeof p.description === "string" ? p.description : "",
    part: p.part ?? "", assay: p.assay ?? "", standard: p.standard ?? "", batchNo: p.batchNo ?? "",
    appearance: p.appearance ?? "", solubility: p.solubility ?? "", lossOnDrying: p.lossOnDrying ?? "",
    heavyMetals: p.heavyMetals ?? "", microbial: p.microbial ?? "", botanical: p.botanical ?? "",
    samplePriceInr: typeof p.samplePriceInr === "number" && p.samplePriceInr > 0 ? p.samplePriceInr : undefined,
    samplePriceUsd: typeof p.samplePriceUsd === "number" && p.samplePriceUsd > 0 ? p.samplePriceUsd : undefined,
  }));
  if (products.length === 0) return null;
  const contact: ContactInfo = { ...DEFAULT_CONTACT, ...(r.contact && typeof r.contact === "object" ? r.contact : {}) };
  contact.salesWhatsapp = Array.isArray(contact.salesWhatsapp)
    ? contact.salesWhatsapp.filter((n): n is string => typeof n === "string").map(digitsOnly).filter((n) => n.length >= 10).slice(0, 6)
    : DEFAULT_CONTACT.salesWhatsapp;
  contact.salesEmails = Array.isArray(contact.salesEmails)
    ? contact.salesEmails.filter((e): e is string => typeof e === "string").map((e) => e.trim()).filter(isEmail).slice(0, 6)
    : DEFAULT_CONTACT.salesEmails;
  return { products, contact, updatedAt: typeof r.updatedAt === "string" ? r.updatedAt : "" };
}

export function loadConfig(): SiteConfig {
  try {
    const saved = localStorage.getItem(CONFIG_KEY);
    if (!saved) return DEFAULT_CONFIG;
    return sanitizeConfig(JSON.parse(saved)) ?? DEFAULT_CONFIG;
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveConfig(config: SiteConfig): SiteConfig {
  const next = { ...config, updatedAt: new Date().toISOString() };
  try { localStorage.setItem(CONFIG_KEY, JSON.stringify(next)); } catch { /* storage unavailable */ }
  return next;
}

export function resetConfig() {
  try { localStorage.removeItem(CONFIG_KEY); } catch { /* ignore */ }
  return DEFAULT_CONFIG;
}

export function hasCustomConfig() {
  try { return localStorage.getItem(CONFIG_KEY) !== null; } catch { return false; }
}

export function loadPin() {
  try { return localStorage.getItem(PIN_KEY) || DEFAULT_ADMIN_PIN; } catch { return DEFAULT_ADMIN_PIN; }
}

export function savePin(pin: string) {
  try { localStorage.setItem(PIN_KEY, pin); } catch { /* ignore */ }
}

export function newProductTemplate(): Product {
  const stamp = Date.now().toString(36).slice(-5).toUpperCase();
  return {
    id: `new-extract-${stamp.toLowerCase()}`,
    name: "New Botanical Extract",
    botanical: "Botanical name",
    part: "Plant part",
    assay: "≥ 0.0% Active marker",
    standard: "HPLC",
    priceInr: 0,
    priceUsd: 0,
    stockKg: 0,
    batchNo: `MPE-NEW-${stamp}`,
    appearance: "Fine powder",
    solubility: "",
    lossOnDrying: "≤ 5.0% w/w",
    heavyMetals: "",
    microbial: "",
    applications: [],
    description: "",
    image: IMAGES.gymnema,
    popular: false,
    samplePriceInr: undefined,
  };
}

/** Human-readable summary used for the email body and the exported text. */
export function summarizeConfig(config: SiteConfig) {
  const c = config.contact;
  const lines = [
    `MANGLAM PHYTOO — SITE CONTENT UPDATE`,
    `Generated: ${new Date().toLocaleString("en-IN")}`,
    ``,
    `PRODUCTS (${config.products.length})`,
    ...config.products.map((p, i) => `${i + 1}. ${p.name} — Rs ${p.priceInr.toLocaleString("en-IN")} / $${p.priceUsd.toFixed(2)} per kg${p.samplePriceInr ? ` | Sample 50 g: Rs ${p.samplePriceInr}` : ""}${p.popular ? " [Featured]" : ""}`),
    ``,
    `CONTACT`,
    `Company: ${c.companyName}`,
    `Desk 1: ${formatPhone(c.desk1)}`,
    `Desk 2: ${formatPhone(c.desk2)}`,
    `WhatsApp 1: ${formatPhone(c.whatsapp1)}`,
    `WhatsApp 2: ${formatPhone(c.whatsapp2)}`,
    `Email: ${c.email}`,
    `Address: ${c.addressLine1} ${c.addressLine2}, ${c.city} (${c.postalCode}), ${c.region}`,
    `Hours: ${c.hours}`,
    `Order alerts (WhatsApp): ${c.salesWhatsapp.map(formatPhone).join(", ") || "none"}`,
    `Order alerts (Email): ${c.salesEmails.join(", ") || "none"}`,
    ``,
    `The full JSON backup (site-config.json) is downloaded alongside this message — attach it to this email.`,
  ];
  return lines.join("\n");
}

export function configMailto(config: SiteConfig, to: string) {
  const subject = encodeURIComponent(`Manglam Phytoo website update — ${new Date().toLocaleDateString("en-IN")}`);
  const body = encodeURIComponent(summarizeConfig(config));
  return `mailto:${to}?subject=${subject}&body=${body}`;
}

export function downloadConfigJson(config: SiteConfig) {
  const blob = new Blob([JSON.stringify(config, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "site-config.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
