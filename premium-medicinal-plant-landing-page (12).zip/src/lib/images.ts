import gymnema from "../../public/images/product-gymnema.jpg?inline";
import berberine from "../../public/images/product-berberine.jpg?inline";
import ashwagandha from "../../public/images/product-ashwagandha.jpg?inline";
import ashwagandha5 from "../../public/images/product-ashwagandha-5.jpg?inline";
import methidana from "../../public/images/product-methidana.jpg?inline";
import hero from "../../public/images/phytoo-hero.png?inline";

export const IMAGES = {
  gymnema,
  berberine,
  ashwagandha,
  ashwagandha5,
  methidana,
  hero,
} as const;
