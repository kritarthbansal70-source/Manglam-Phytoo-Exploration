import { useEffect, useRef, useState, type FormEvent } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, Copy, Download, Leaf, Mail, MapPin, MessageCircle, Minus, Package, Pencil, Plus, Send, ShoppingBag, Trash2, X } from "lucide-react";
import { Dialog } from "./Dialog";
import {
  cartTotals, downloadText, EMPTY_ADDRESS, formatMoney, linePricing, normalizeQuantity, SAMPLE_GRAMS, validateAddress,
  type AddressErrors, type CartItem, type Currency, type DeliveryAddress,
} from "../lib/commerce";
import { formatPhone, orderMailto, waLink } from "../lib/siteConfig";

type Step = "bag" | "delivery" | "review" | "complete";

interface CheckoutProps {
  open: boolean;
  items: CartItem[];
  currency: Currency;
  /** WhatsApp numbers that should receive the order after checkout. */
  salesNumbers: string[];
  /** Email addresses that should receive the order after checkout. */
  salesEmails: string[];
  onClose: () => void;
  onRemove: (index: number) => void;
  onQuantityChange: (index: number, quantity: number) => void;
  onCurrencyChange: (currency: Currency) => void;
  onComplete: () => void;
}

interface PreparedRequest {
  reference: string;
  contents: string;
  /** Shorter text that fits comfortably in a WhatsApp message. */
  whatsappText: string;
  /** Full order details formatted for the sales email. */
  emailBody: string;
  recipient: string;
}

/** Compact order summary for WhatsApp (URL-encoded length stays well under browser limits). */
function prepareWhatsappText(items: CartItem[], address: DeliveryAddress, currency: Currency, reference: string) {
  const total = cartTotals(items, currency);
  const anyPriced = items.some((item) => linePricing(item, currency).priced);
  const lines = items.map((item) => {
    const p = linePricing(item, currency);
    if (item.type === "sample") return `• ${item.product.name} — ${item.qty} × ${SAMPLE_GRAMS} g sample${p.priced ? ` = ${formatMoney(p.total, currency)}` : " (on request)"}`;
    return `• ${item.product.name} — ${item.qty} kg @ ${formatMoney(p.unit, currency)}/kg = ${formatMoney(p.total, currency)}`;
  });
  return [
    `*NEW ORDER REQUEST — ${reference}*`,
    `Manglam Phytoo Exploration website`,
    ``,
    `*Products*`,
    ...lines,
    ``,
    `*Estimated subtotal:* ${anyPriced ? formatMoney(total.total, currency) : "On request"}${total.savings > 0 ? ` (volume savings ${formatMoney(total.savings, currency)})` : ""}`,
    ``,
    `*Buyer*`,
    `${address.fullName}, ${address.company}`,
    `${address.email} | ${address.phone}`,
    ``,
    `*Deliver to*`,
    address.addressLine1,
    ...(address.addressLine2 ? [address.addressLine2] : []),
    `${address.city}, ${address.region} ${address.postalCode}`,
    address.country,
    ...(address.instructions ? [``, `Instructions: ${address.instructions}`] : []),
    ``,
    `_Freight, taxes and final availability to be confirmed by sales._`,
  ].join("\n");
}

const STEPS: { key: Step; label: string }[] = [
  { key: "bag", label: "Your selection" },
  { key: "delivery", label: "Delivery" },
  { key: "review", label: "Review" },
];

const COUNTRIES = ["India", "United States", "United Kingdom", "Canada", "Australia", "Germany", "France", "Netherlands", "Italy", "Spain", "Switzerland", "Sweden", "Singapore", "United Arab Emirates", "Saudi Arabia", "South Africa", "Japan", "New Zealand", "Brazil", "Nepal", "Bangladesh", "Sri Lanka"];

function QuantityControl({ item, onChange }: { item: CartItem; onChange: (quantity: number) => void }) {
  const [draft, setDraft] = useState(String(item.qty));
  useEffect(() => setDraft(String(item.qty)), [item.qty]);
  const step = item.type === "sample" ? 1 : 25;
  const max = item.type === "sample" ? 10 : 10000;

  const commit = () => {
    const next = normalizeQuantity(Number(draft), item.type);
    setDraft(String(next));
    onChange(next);
  };

  return (
    <div className="inline-flex h-10 items-center rounded border border-outline-variant bg-surface-container-low">
      <button type="button" className="grid h-full w-10 place-items-center text-primary hover:bg-primary/5" aria-label={`Decrease ${item.product.name} quantity`} disabled={item.qty <= step} onClick={() => onChange(item.qty - step)}>
        <Minus size={13} aria-hidden="true" />
      </button>
      <input
        className="checkout-quantity h-full w-16 bg-transparent text-center font-mono-data text-xs text-primary outline-none"
        type="number" inputMode="numeric" min={step} max={max} step={step}
        aria-label={`${item.product.name} quantity in ${item.type === "sample" ? "sample kits" : "kilograms"}`}
        value={draft}
        onChange={(event) => {
          const value = event.target.value;
          setDraft(value);
          const quantity = Number(value);
          if (value.trim() && quantity >= step && quantity <= max && quantity % step === 0) onChange(quantity);
        }}
        onBlur={commit}
        onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); commit(); } }}
      />
      <button type="button" className="grid h-full w-10 place-items-center text-primary hover:bg-primary/5" aria-label={`Increase ${item.product.name} quantity`} disabled={item.qty >= max} onClick={() => onChange(item.qty + step)}>
        <Plus size={13} aria-hidden="true" />
      </button>
    </div>
  );
}

function DeliveryField({ name, label, value, error, onChange, autoComplete, type = "text", optional = false, wide = false, placeholder = "", list }: {
  name: keyof DeliveryAddress;
  label: string;
  value: string;
  error?: string;
  onChange: (name: keyof DeliveryAddress, value: string) => void;
  autoComplete: string;
  type?: string;
  optional?: boolean;
  wide?: boolean;
  placeholder?: string;
  list?: string;
}) {
  return (
    <label htmlFor={`delivery-${name}`} className={`checkout-field ${wide ? "sm:col-span-2" : ""}`}>
      <span>{label}{optional ? <span className="ml-1 font-normal text-outline">(optional)</span> : <span className="ml-1 text-tertiary" aria-hidden="true">*</span>}</span>
      <input
        id={`delivery-${name}`} name={name} value={value} onChange={(event) => onChange(name, event.target.value)}
        type={type} autoComplete={`shipping ${autoComplete}`} required={!optional} placeholder={placeholder}
        maxLength={name === "phone" ? 30 : name === "postalCode" ? 14 : 180}
        aria-invalid={!!error} aria-describedby={error ? `delivery-${name}-error` : undefined}
        list={list}
      />
      {error && <span id={`delivery-${name}-error`} className="field-error">{error}</span>}
    </label>
  );
}

function Estimate({ items, currency }: { items: CartItem[]; currency: Currency }) {
  const { total, savings } = cartTotals(items, currency);
  const anyPriced = items.some((item) => linePricing(item, currency).priced);
  const anyUnpriced = items.some((item) => !linePricing(item, currency).priced);

  return (
    <div className="space-y-2.5 text-sm" aria-live="polite" aria-atomic="true">
      {savings > 0 && <div className="flex justify-between text-primary-container"><span>Volume savings</span><span className="font-mono-data text-xs">-{formatMoney(savings, currency)}</span></div>}
      <div className="flex items-baseline justify-between gap-4">
        <span className="font-semibold text-primary">Estimated subtotal</span>
        <span className="price-value font-display-lg text-2xl font-semibold text-primary">{anyPriced ? formatMoney(total, currency) : "On request"}</span>
      </div>
      <p className="text-[11px] leading-relaxed text-on-surface-variant">
        {anyUnpriced ? "Some items are priced on request. " : ""}Freight and taxes are quoted separately. Final rates are subject to confirmation.
      </p>
    </div>
  );
}

function prepareSummary(items: CartItem[], address: DeliveryAddress, currency: Currency, reference: string) {
  const total = cartTotals(items, currency);
  const lines = items.map((item, index) => {
    const price = linePricing(item, currency);
    if (item.type === "sample") {
      return `${index + 1}. ${item.product.name}\n   ${item.qty} x ${SAMPLE_GRAMS} g analytical sample kit(s)${price.priced ? ` x ${formatMoney(price.unit, currency)} | ${formatMoney(price.total, currency)}` : " | Price on request"}`;
    }
    return `${index + 1}. ${item.product.name}\n   ${item.qty} kg x ${formatMoney(price.unit, currency)} / kg | ${formatMoney(price.total, currency)}${price.discount ? ` (${price.discount}% volume discount)` : ""}`;
  });
  const anyPriced = items.some((item) => linePricing(item, currency).priced);
  return [
    "MANGLAM PHYTOO EXPLORATION", "B2B ORDER REQUEST (NOT A CONFIRMED ORDER)",
    `Reference: ${reference}`, `Prepared: ${new Date().toISOString()}`, `Currency: ${currency}`,
    "", "PRODUCT SELECTION", ...lines,
    "", `Estimated subtotal: ${anyPriced ? formatMoney(total.total, currency) : "On request"}`,
    `Volume savings: ${formatMoney(total.savings, currency)}`,
    "Freight, taxes, and final availability require a separate quotation.",
    "", "DELIVERY ADDRESS", address.fullName, address.company, address.addressLine1,
    ...(address.addressLine2 ? [address.addressLine2] : []),
    `${address.city}, ${address.region} ${address.postalCode}`, address.country,
    `Email: ${address.email}`, `Phone: ${address.phone}`,
    ...(address.instructions ? [`Delivery instructions: ${address.instructions}`] : []),
    "", "This request was prepared locally in your browser. It has not been sent to the seller.",
    "No payment has been collected. Share this document with your verified sales contact to confirm your order.",
  ].join("\n");
}

/** Full order email addressed to the sales team — every detail sales needs to quote and dispatch. */
function prepareEmailBody(items: CartItem[], address: DeliveryAddress, currency: Currency, reference: string) {
  const total = cartTotals(items, currency);
  const anyPriced = items.some((item) => linePricing(item, currency).priced);
  const commercialKg = items.filter((i) => i.type === "commercial").reduce((s, i) => s + i.qty, 0);
  const sampleKits = items.filter((i) => i.type === "sample").reduce((s, i) => s + i.qty, 0);
  const when = new Date();

  const productLines = items.map((item, index) => {
    const p = linePricing(item, currency);
    const head = `${index + 1}) ${item.product.name}`;
    const spec = `   Botanical: ${item.product.botanical} | Assay: ${item.product.assay} | Batch: ${item.product.batchNo}`;
    if (item.type === "sample") {
      const price = p.priced ? `${formatMoney(p.unit, currency)} per kit | Line total: ${formatMoney(p.total, currency)}` : "Price on request";
      return [head, `   Type: Analytical sample kit (${SAMPLE_GRAMS} g each)`, `   Quantity: ${item.qty} kit${item.qty === 1 ? "" : "s"}`, `   ${price}`, spec].join("\n");
    }
    const disc = p.discount ? ` (after ${p.discount}% volume discount)` : "";
    return [head, `   Type: Commercial supply`, `   Quantity: ${item.qty} kg`, `   Rate: ${formatMoney(p.unit, currency)} / kg${disc} | Line total: ${formatMoney(p.total, currency)}`, spec].join("\n");
  });

  return [
    `NEW ORDER REQUEST — ${reference}`,
    `Source: Manglam Phytoo Exploration website`,
    `Received: ${when.toLocaleString("en-IN", { dateStyle: "full", timeStyle: "short" })} (${when.toISOString()})`,
    `Currency: ${currency}`,
    ``,
    `============================================`,
    `BUYER`,
    `============================================`,
    `Name:     ${address.fullName}`,
    `Company:  ${address.company}`,
    `Email:    ${address.email}`,
    `Phone:    ${address.phone}`,
    ``,
    `============================================`,
    `PRODUCTS ORDERED (${items.length} line${items.length === 1 ? "" : "s"})`,
    `============================================`,
    ...productLines.flatMap((l) => [l, ""]),
    `Total commercial quantity: ${commercialKg} kg`,
    `Total sample kits:         ${sampleKits} x ${SAMPLE_GRAMS} g`,
    `Volume savings applied:    ${formatMoney(total.savings, currency)}`,
    `ESTIMATED SUBTOTAL:        ${anyPriced ? formatMoney(total.total, currency) : "On request"}`,
    `(Freight, taxes and final availability to be confirmed by sales.)`,
    ``,
    `============================================`,
    `DELIVERY ADDRESS`,
    `============================================`,
    address.fullName,
    address.company,
    address.addressLine1,
    ...(address.addressLine2 ? [address.addressLine2] : []),
    `${address.city}, ${address.region} ${address.postalCode}`,
    address.country,
    ...(address.instructions ? [``, `Delivery instructions: ${address.instructions}`] : []),
    ``,
    `============================================`,
    `NEXT STEPS FOR SALES`,
    `============================================`,
    `1. Confirm stock and current batch COA for each product.`,
    `2. Quote freight and applicable taxes to the delivery address above.`,
    `3. Send proforma invoice to ${address.email} / ${address.phone}.`,
    ``,
    `Reference ${reference} — please quote this in all replies.`,
  ].join("\n");
}

export function CheckoutDrawer({ open, items, currency, salesNumbers, salesEmails, onClose, onRemove, onQuantityChange, onCurrencyChange, onComplete }: CheckoutProps) {
  const [step, setStep] = useState<Step>("bag");
  const [address, setAddress] = useState<DeliveryAddress>({ ...EMPTY_ADDRESS });
  const [errors, setErrors] = useState<AddressErrors>({});
  const [consent, setConsent] = useState(false);
  const [prepared, setPrepared] = useState<PreparedRequest | null>(null);
  const [copyStatus, setCopyStatus] = useState("");
  const [sentTo, setSentTo] = useState<string[]>([]);
  const [emailed, setEmailed] = useState(false);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const returnToCatalog = useRef(false);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    if (open) {
      if (!prepared || items.length > 0) { setStep("bag"); setPrepared(null); setSentTo([]); setEmailed(false); }
      setConsent(false);
      setCopyStatus("");
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const frame = requestAnimationFrame(() => {
      contentRef.current?.scrollTo({ top: 0, behavior: "instant" });
      headingRef.current?.focus({ preventScroll: true });
    });
    return () => cancelAnimationFrame(frame);
  }, [step, open]);

  const updateAddress = (field: keyof DeliveryAddress, value: string) => {
    setAddress((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    setConsent(false);
  };

  const submitAddress = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextErrors = validateAddress(address);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) {
      requestAnimationFrame(() => document.getElementById(`delivery-${Object.keys(nextErrors)[0]}`)?.focus());
      return;
    }
    setAddress(Object.fromEntries(Object.entries(address).map(([key, value]) => [key, value.trim()])) as unknown as DeliveryAddress);
    setStep("review");
  };

  const finishRequest = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (step !== "review" || !consent || items.length === 0 || prepared) return;
    const nextErrors = validateAddress(address);
    if (Object.keys(nextErrors).length) { setErrors(nextErrors); setStep("delivery"); return; }
    const reference = `MPE-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
    const whatsappText = prepareWhatsappText(items, address, currency, reference);
    const emailBody = prepareEmailBody(items, address, currency, reference);
    const contents = prepareSummary(items, address, currency, reference);
    setPrepared({ reference, contents, whatsappText, emailBody, recipient: address.fullName });
    setSentTo([]);
    setCopyStatus("");

    // Redirect straight to the buyer's email app with every sales address and the full
    // order pre-filled. Must run synchronously inside the submit handler so the browser
    // treats it as user-initiated.
    if (salesEmails.length > 0) {
      // Save a local copy first — some mail clients truncate very long mailto bodies.
      downloadText(`${reference}.txt`, contents);
      window.location.href = orderMailto(salesEmails, `New order request ${reference} — ${address.fullName}, ${address.company}`, emailBody);
      setEmailed(true);
    } else {
      setEmailed(false);
    }

    setStep("complete");
    onComplete();
  };

  const salesLink = (number: string) => (prepared ? waLink(number, encodeURIComponent(prepared.whatsappText)) : "#");

  const emailLink = prepared
    ? orderMailto(salesEmails, `New order request ${prepared.reference} — ${prepared.recipient}`, prepared.emailBody)
    : "#";

  const sendEmail = () => {
    if (!prepared || salesEmails.length === 0) return;
    window.location.href = emailLink;
    setEmailed(true);
    setCopyStatus("Your email app should open with the order addressed to sales. Attach the downloaded .txt if the body looks cut off.");
  };

  const markSent = (number: string) => setSentTo((prev) => (prev.includes(number) ? prev : [...prev, number]));

  /** Open each sales chat in turn; browsers may block extra tabs, so we stagger and fall back gracefully. */
  const sendToAll = () => {
    if (!prepared) return;
    const pending = salesNumbers.filter((n) => !sentTo.includes(n));
    pending.forEach((number, index) => {
      window.setTimeout(() => {
        const win = window.open(salesLink(number), "_blank", "noopener,noreferrer");
        if (win) markSent(number);
        else setCopyStatus("Your browser blocked extra tabs — tap each sales number below to send one at a time.");
      }, index * 700);
    });
  };

  const explore = () => {
    returnToCatalog.current = true;
    onClose();
  };

  const copyRequest = async () => {
    if (!prepared) return;
    try {
      await navigator.clipboard.writeText(prepared.contents);
      setCopyStatus("Request copied to your clipboard.");
    } catch { setCopyStatus("Clipboard unavailable. Please download the request instead."); }
  };

  const stepIndex = step === "complete" ? 3 : STEPS.findIndex((entry) => entry.key === step);
  const titles = { bag: "Your botanical selection", delivery: "Where should we deliver?", review: "Review your request", complete: "Your request is ready" };

  return (
    <AnimatePresence onExitComplete={() => {
      if (!returnToCatalog.current) return;
      returnToCatalog.current = false;
      requestAnimationFrame(() => {
        document.getElementById("products")?.scrollIntoView({ behavior: reduceMotion ? "instant" : "smooth" });
        document.getElementById("product-search")?.focus({ preventScroll: true });
      });
    }}>
      {open && (
        <Dialog key="checkout" labelId="checkout-heading" descriptionId="checkout-description" onClose={onClose} drawer>
          <div className="shrink-0 border-b border-outline-variant/50 px-5 pb-6 pt-6 sm:px-8 sm:pt-8">
            <div className="mb-6 flex items-center justify-between">
              <span className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-secondary"><Leaf size={15} aria-hidden="true" /> Manglam Phytoo</span>
              <button type="button" onClick={onClose} aria-label="Close checkout" className="interactive-button grid h-10 w-10 place-items-center rounded-full border border-outline-variant/50 text-primary hover:bg-surface-container-high"><X size={18} aria-hidden="true" /></button>
            </div>
            <h2 ref={headingRef} tabIndex={-1} data-dialog-heading id="checkout-heading" className="font-display-lg text-[28px] leading-tight text-primary outline-none sm:text-[32px]">{titles[step]}</h2>
            <p id="checkout-description" className="mt-2 text-sm leading-6 text-on-surface-variant">
              {step === "bag" && "A considered start to your next formulation."}
              {step === "delivery" && "Add your contact and delivery address before checkout."}
              {step === "review" && "One final check of your extracts and delivery details."}
              {step === "complete" && "Your order has been sent to your email app for delivery to our sales team."}
            </p>
            {(items.length > 0 || step === "complete") && (
              <ol className="mt-6 grid grid-cols-3 gap-3" aria-label="Checkout progress">
                {STEPS.map((entry, index) => (
                  <li key={entry.key} className={`border-t-2 pt-3 ${index <= stepIndex ? "border-tertiary" : "border-outline-variant/45"}`} aria-current={index === stepIndex ? "step" : undefined}>
                    {index < stepIndex && step !== "complete" ? (
                      <button type="button" onClick={() => { setStep(entry.key); setConsent(false); }} className="flex items-center gap-1.5 text-[11px] font-medium text-tertiary hover:text-primary"><Check size={12} aria-hidden="true" />{entry.label}</button>
                    ) : (
                      <span className={`flex items-center gap-1.5 text-[11px] font-medium ${index <= stepIndex ? "text-primary" : "text-outline"}`}>
                        {index < stepIndex ? <Check size={12} aria-hidden="true" /> : <span className="font-mono-data text-[10px]">0{index + 1}</span>}{entry.label}
                      </span>
                    )}
                  </li>
                ))}
              </ol>
            )}
          </div>

          <div ref={contentRef} className="checkout-scroll px-5 py-6 sm:px-8">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={step} initial={{ opacity: 0, y: reduceMotion ? 0 : 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: reduceMotion ? 0 : -6 }} transition={{ duration: 0.2 }}>
                {step === "bag" && (items.length === 0 ? (
                  <div className="flex min-h-80 flex-col items-center justify-center text-center">
                    <ShoppingBag size={38} strokeWidth={1.2} className="text-tertiary" aria-hidden="true" />
                    <h3 className="mt-6 font-display-lg text-2xl text-primary">Good things start here.</h3>
                    <p className="mt-3 max-w-xs text-sm leading-6 text-on-surface-variant">Choose an extract or a sample kit to start your order request.</p>
                    <button type="button" onClick={explore} className="interactive-button mt-7 inline-flex items-center gap-2 rounded bg-primary px-6 py-3 text-sm font-semibold text-white">Explore extracts <ArrowRight size={15} aria-hidden="true" /></button>
                  </div>
                ) : (
                  <>
                    <div className="mb-5 flex items-center justify-between gap-3 text-xs">
                      <p className="text-on-surface-variant">{items.length} {items.length === 1 ? "selection" : "selections"}</p>
                      <div className="flex items-center gap-1" role="group" aria-label="Checkout currency">
                        {(["INR", "USD"] as const).map((value) => <button key={value} type="button" onClick={() => onCurrencyChange(value)} aria-pressed={currency === value} className={`min-h-9 rounded px-3 font-mono-data text-[11px] transition-colors ${currency === value ? "bg-primary text-white" : "text-secondary hover:bg-surface-container"}`}>{value}</button>)}
                      </div>
                    </div>
                    <div className="divide-y divide-outline-variant/45">
                      <AnimatePresence initial={false}>
                        {items.map((item, index) => {
                          const price = linePricing(item, currency);
                          return (
                            <motion.div key={`${item.product.id}-${item.type}`} layout={!reduceMotion} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, height: 0, overflow: "hidden" }} className="py-5 first:pt-0">
                              <div className="flex items-start justify-between gap-3">
                                <div className="min-w-0">
                                  <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-secondary">{item.type === "sample" ? "Analytical sample" : "Commercial extract"}</p>
                                  <h3 className="font-display-lg text-lg font-medium text-primary">{item.product.name}</h3>
                                  <p className="mt-1 text-xs text-on-surface-variant">{item.type === "sample" ? (price.priced ? `${SAMPLE_GRAMS} g per kit at ${formatMoney(price.unit, currency)} / kit.` : `${SAMPLE_GRAMS} g per sample kit. Price quoted separately.`) : `${formatMoney(price.unit, currency)} / kg${price.discount ? `, ${price.discount}% volume saving` : ""}`}</p>
                                </div>
                                <button type="button" onClick={() => onRemove(index)} aria-label={`Remove ${item.product.name} ${item.type}`} className="grid h-9 w-9 shrink-0 place-items-center rounded text-outline hover:bg-red-50 hover:text-error"><Trash2 size={15} aria-hidden="true" /></button>
                              </div>
                              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                                <div className="flex items-center gap-2">
                                  <QuantityControl item={item} onChange={(quantity) => onQuantityChange(index, quantity)} />
                                  <span className="font-mono-data text-[11px] text-outline">{item.type === "sample" ? "kits" : "kg"}</span>
                                </div>
                                <span className="price-value text-sm font-semibold text-primary">{price.priced ? formatMoney(price.total, currency) : "On request"}</span>
                              </div>
                            </motion.div>
                          );
                        })}
                      </AnimatePresence>
                    </div>
                    <button type="button" onClick={explore} className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-secondary hover:text-primary"><Plus size={14} aria-hidden="true" /> Add another extract</button>
                    <p className="mt-6 flex items-start gap-2 border-t border-outline-variant/40 pt-5 text-xs leading-5 text-on-surface-variant"><Package size={16} className="mt-0.5 shrink-0 text-tertiary" aria-hidden="true" />Commercial quantities are ordered in 25 kg increments. Sample kits are {SAMPLE_GRAMS} g each.</p>
                  </>
                ))}

                {step === "delivery" && (
                  <form id="delivery-address-form" onSubmit={submitAddress} noValidate>
                    <p className="mb-5 text-[11px] text-outline">Fields marked * are required. Your address is not saved to browser storage.</p>
                    {Object.values(errors).some(Boolean) && <p role="alert" className="mb-5 text-sm text-error">Please check the highlighted delivery details.</p>}
                    <div className="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2">
                      <DeliveryField name="fullName" label="Recipient's full name" value={address.fullName} error={errors.fullName} onChange={updateAddress} autoComplete="name" placeholder="Full name" />
                      <DeliveryField name="company" label="Company / laboratory" value={address.company} error={errors.company} onChange={updateAddress} autoComplete="organization" placeholder="Organization name" />
                      <DeliveryField name="email" label="Email address" value={address.email} error={errors.email} onChange={updateAddress} autoComplete="email" type="email" placeholder="you@company.com" />
                      <DeliveryField name="phone" label="Phone number" value={address.phone} error={errors.phone} onChange={updateAddress} autoComplete="tel" type="tel" placeholder="Include country code" />
                      <div className="mt-3 border-t border-outline-variant/50 pt-5 sm:col-span-2"><h3 className="flex items-center gap-2 text-sm font-semibold text-primary"><MapPin size={16} className="text-tertiary" aria-hidden="true" /> Delivery address</h3></div>
                      <DeliveryField name="addressLine1" label="Street address" value={address.addressLine1} error={errors.addressLine1} onChange={updateAddress} autoComplete="address-line1" placeholder="Building number and street name" wide />
                      <DeliveryField name="addressLine2" label="Apartment, suite, or unit" value={address.addressLine2} onChange={updateAddress} autoComplete="address-line2" optional wide />
                      <DeliveryField name="city" label="City" value={address.city} error={errors.city} onChange={updateAddress} autoComplete="address-level2" placeholder="City" />
                      <DeliveryField name="region" label="State / province / region" value={address.region} error={errors.region} onChange={updateAddress} autoComplete="address-level1" placeholder="State or province" />
                      <DeliveryField name="country" label="Country" value={address.country} error={errors.country} onChange={updateAddress} autoComplete="country-name" list="delivery-countries" />
                      <DeliveryField name="postalCode" label="Postal / ZIP code" value={address.postalCode} error={errors.postalCode} onChange={updateAddress} autoComplete="postal-code" placeholder={address.country.toLowerCase() === "india" ? "6-digit PIN code" : "Postal code or N/A"} />
                      <label className="checkout-field mt-2 sm:col-span-2" htmlFor="delivery-instructions"><span>Delivery instructions <span className="font-normal text-outline">(optional)</span></span><textarea id="delivery-instructions" name="instructions" rows={2} maxLength={500} value={address.instructions} onChange={(event) => updateAddress("instructions", event.target.value)} placeholder="Receiving hours, delivery gate, or special requirements" /></label>
                    </div>
                    <datalist id="delivery-countries">{COUNTRIES.map((country) => <option key={country} value={country} />)}</datalist>
                  </form>
                )}

                {step === "review" && (
                  <form id="checkout-review-form" onSubmit={finishRequest}>
                    <div className="mb-4 flex items-center justify-between"><h3 className="font-display-lg text-xl text-primary">Your extracts</h3><button type="button" onClick={() => { setStep("bag"); setConsent(false); }} className="inline-flex min-h-9 items-center gap-1.5 text-xs font-semibold text-secondary"><Pencil size={12} aria-hidden="true" /> Edit items</button></div>
                    <div className="divide-y divide-outline-variant/40">
                      {items.map((item) => { const lp = linePricing(item, currency); return <div key={`${item.product.id}-${item.type}`} className="flex justify-between gap-5 py-3 text-sm"><div><p className="font-medium text-primary">{item.product.name}</p><p className="mt-1 text-xs text-outline">{item.type === "sample" ? `${item.qty} x ${SAMPLE_GRAMS} g sample kit${item.qty === 1 ? "" : "s"}${lp.priced ? ` at ${formatMoney(lp.unit, currency)} / kit` : ""}` : `${item.qty} kg at ${formatMoney(lp.unit, currency)} / kg`}</p></div><p className="shrink-0 font-mono-data text-xs text-primary">{lp.priced ? formatMoney(lp.total, currency) : "On request"}</p></div>; })}
                    </div>
                    <div className="mt-7 border-y border-outline-variant/50 py-5">
                      <div className="mb-3 flex items-center justify-between"><h3 className="flex items-center gap-2 text-sm font-semibold text-primary"><MapPin size={16} className="text-tertiary" aria-hidden="true" /> Deliver to</h3><button type="button" onClick={() => { setStep("delivery"); setConsent(false); }} className="inline-flex min-h-9 items-center gap-1.5 text-xs font-semibold text-secondary"><Pencil size={12} aria-hidden="true" /> Edit address</button></div>
                      <address className="break-words text-sm not-italic leading-6 text-on-surface-variant"><span className="font-semibold text-primary">{address.fullName}</span><br />{address.company}<br />{address.addressLine1}<br />{address.addressLine2 && <>{address.addressLine2}<br /></>}{address.city}, {address.region} {address.postalCode}<br />{address.country}</address>
                      <p className="mt-3 break-words text-xs leading-6 text-secondary">{address.email}<br />{address.phone}</p>
                      {address.instructions && <p className="mt-3 break-words text-xs leading-5 text-on-surface-variant"><span className="font-semibold">Instructions: </span>{address.instructions}</p>}
                    </div>
                    <label className="mt-6 flex cursor-pointer items-start gap-3 text-sm leading-6 text-on-surface-variant"><input type="checkbox" required checked={consent} onChange={(event) => setConsent(event.target.checked)} className="mt-1 h-4 w-4 shrink-0 accent-primary" /><span>I have checked the delivery address and product quantities.</span></label>
                    <p className="mt-4 text-xs leading-5 text-outline">Confirming will open your email app with the complete order addressed to our sales team — just press Send there. This is an order request, not a paid or confirmed order.</p>
                  </form>
                )}

                {step === "complete" && prepared && (
                  <div className="py-5">
                    <div className="text-center">
                      <motion.div initial={{ scale: reduceMotion ? 1 : 0.8 }} animate={{ scale: 1 }} className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-primary text-tertiary-fixed"><Mail size={28} strokeWidth={1.4} aria-hidden="true" /></motion.div>
                      <h3 className="mt-6 font-display-lg text-2xl text-primary">{emailed ? "Opening your email app…" : "Order request ready"}</h3>
                      <p className="mx-auto mt-3 max-w-sm text-sm leading-6 text-on-surface-variant">
                        {emailed
                          ? <>Thank you, {prepared.recipient}. Your email app has opened with the complete order addressed to our sales team — press <span className="font-semibold text-primary">Send</span> there to deliver it.</>
                          : <>Thank you, {prepared.recipient}. Tap below to open your email app with the complete order pre-filled, then press Send.</>}
                      </p>
                      <p className="my-5 font-mono-data text-xs text-secondary">{prepared.reference}</p>
                    </div>

                    {salesEmails.length > 0 && (
                      <div className="rounded-lg border border-primary/30 bg-surface-container-low p-4">
                        <div className="mb-3 flex items-center justify-between gap-3">
                          <span className="flex items-center gap-2 text-sm font-semibold text-primary"><Mail size={16} aria-hidden="true" /> {emailed ? "Email didn't open?" : "Email order to sales"}</span>
                          {emailed && <span className="flex items-center gap-1 font-mono-data text-[11px] text-emerald-800"><Check size={12} aria-hidden="true" /> Opened</span>}
                        </div>
                        <button type="button" onClick={sendEmail} className="interactive-button flex min-h-12 w-full items-center justify-center gap-2 rounded bg-primary px-5 text-sm font-semibold text-white hover:bg-primary-container">
                          <Mail size={15} aria-hidden="true" /> {emailed ? "Open email again" : `Open email to sales (${salesEmails.length} recipients)`}
                        </button>
                        <ul className="mt-3 space-y-1">
                          {salesEmails.map((email) => (
                            <li key={email} className="flex items-center gap-2 break-all text-xs text-on-surface-variant"><Check size={12} className="shrink-0 text-tertiary" aria-hidden="true" />{email}</li>
                          ))}
                        </ul>
                        <p className="mt-3 text-[11px] leading-5 text-outline">The email contains every product, quantity, price, your contact details and the delivery address. A .txt copy has been downloaded — attach it if your mail app cut the message short.</p>
                      </div>
                    )}

                    {salesNumbers.length > 0 && (
                      <div className="mt-4 rounded-lg border border-emerald-600/40 bg-emerald-50 p-4">
                        <div className="mb-3 flex items-center justify-between gap-3">
                          <span className="flex items-center gap-2 text-sm font-semibold text-emerald-900"><MessageCircle size={16} aria-hidden="true" /> Also send on WhatsApp</span>
                          <span className="font-mono-data text-[11px] text-emerald-800">{sentTo.length}/{salesNumbers.length} opened</span>
                        </div>
                        {sentTo.length < salesNumbers.length && (
                          <button type="button" onClick={sendToAll} className="interactive-button flex min-h-11 w-full items-center justify-center gap-2 rounded bg-emerald-800 px-5 text-xs font-semibold text-white hover:bg-emerald-700">
                            <Send size={14} aria-hidden="true" /> {sentTo.length ? `Send to the other ${salesNumbers.length - sentTo.length}` : `Send to all ${salesNumbers.length} sales numbers`}
                          </button>
                        )}
                        <ul className="mt-3 space-y-2">
                          {salesNumbers.map((number, index) => {
                            const done = sentTo.includes(number);
                            return (
                              <li key={number}>
                                <a
                                  href={salesLink(number)}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  onClick={() => markSent(number)}
                                  className={`flex min-h-11 items-center justify-between gap-3 rounded border px-3 text-sm transition-colors ${done ? "border-emerald-600/50 bg-white text-emerald-900" : "border-emerald-600/30 bg-white/70 text-emerald-900 hover:bg-white"}`}
                                >
                                  <span className="flex items-center gap-2"><MessageCircle size={14} className="text-emerald-700" aria-hidden="true" /> Sales {index + 1}: {formatPhone(number)}</span>
                                  {done ? <span className="flex items-center gap-1 text-[11px] font-semibold"><Check size={13} aria-hidden="true" /> Opened</span> : <span className="text-[11px] font-semibold">Send</span>}
                                </a>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    )}

                    <div className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
                      <button type="button" onClick={() => downloadText(`${prepared.reference}.txt`, prepared.contents)} className="interactive-button flex min-h-11 items-center justify-center gap-2 rounded border border-outline-variant px-4 text-xs font-semibold text-primary hover:bg-surface-container"><Download size={14} aria-hidden="true" /> Download copy</button>
                      <button type="button" onClick={copyRequest} className="flex min-h-11 items-center justify-center gap-2 rounded border border-outline-variant px-4 text-xs font-semibold text-primary hover:bg-surface-container"><Copy size={14} aria-hidden="true" /> Copy details</button>
                    </div>
                    <p role="status" className="mt-3 min-h-5 text-center text-xs text-secondary">{copyStatus}</p>
                    <p className="mt-3 border-t border-outline-variant/40 pt-4 text-center text-[11px] leading-5 text-outline">No payment has been collected. Our sales team will confirm price, freight and availability by reply.</p>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {(items.length > 0 || step === "complete") && (
            <div className="checkout-footer shrink-0 border-t border-outline-variant/60 bg-surface-container-low px-5 pt-5 sm:px-8">
              {step !== "complete" && <Estimate items={items} currency={currency} />}
              {step === "bag" && <button type="button" onClick={() => setStep("delivery")} className="interactive-button mt-5 flex min-h-12 w-full items-center justify-center gap-3 rounded bg-primary text-sm font-semibold text-white">Continue to checkout <ArrowRight size={16} aria-hidden="true" /></button>}
              {step === "delivery" && <div className="mt-5 flex items-center gap-4"><button type="button" onClick={() => setStep("bag")} aria-label="Back to your selection" className="grid h-12 w-12 shrink-0 place-items-center rounded border border-outline-variant text-primary hover:bg-surface-container"><ArrowLeft size={16} aria-hidden="true" /></button><button type="submit" form="delivery-address-form" className="interactive-button flex min-h-12 flex-1 items-center justify-center gap-3 rounded bg-primary px-4 text-sm font-semibold text-white">Review checkout <ArrowRight size={16} aria-hidden="true" /></button></div>}
              {step === "review" && <button type="submit" form="checkout-review-form" disabled={!consent} className="interactive-button mt-5 flex min-h-12 w-full items-center justify-center gap-3 rounded bg-primary px-4 text-sm font-semibold text-white">Confirm &amp; email order <Mail size={16} aria-hidden="true" /></button>}
              {step === "complete" && <button type="button" onClick={explore} className="flex min-h-11 w-full items-center justify-center gap-2 text-sm font-semibold text-primary">Continue exploring <ArrowRight size={15} aria-hidden="true" /></button>}
            </div>
          )}
        </Dialog>
      )}
    </AnimatePresence>
  );
}