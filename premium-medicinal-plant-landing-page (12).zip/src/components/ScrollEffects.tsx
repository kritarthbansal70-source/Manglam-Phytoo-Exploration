import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import {
  AnimatePresence, animate, motion, useInView, useMotionValueEvent, useReducedMotion, useScroll, useSpring, useTransform,
  type MotionValue,
} from "framer-motion";
import { ArrowUp } from "lucide-react";

const EASE_OUT = [0.22, 1, 0.36, 1] as const;

type Direction = "up" | "down" | "left" | "right" | "none";

const offsetFor = (direction: Direction, distance: number) => {
  switch (direction) {
    case "up": return { y: distance };
    case "down": return { y: -distance };
    case "left": return { x: distance };
    case "right": return { x: -distance };
    default: return {};
  }
};

/** Fade + slide in when scrolled into view. Optional direction, delay and scale for a "pop" feel. */
export function Reveal({
  children, className = "", delay = 0, direction = "up", distance = 28, scale = false, once = true, amount = 0.15,
}: {
  children: ReactNode; className?: string; delay?: number; direction?: Direction; distance?: number; scale?: boolean; once?: boolean; amount?: number;
}) {
  const reduceMotion = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduceMotion ? false : { opacity: 0, ...offsetFor(direction, distance), ...(scale ? { scale: 0.96 } : {}) }}
      whileInView={{ opacity: 1, x: 0, y: 0, scale: 1 }}
      viewport={{ once, amount, margin: "0px 0px -40px 0px" }}
      transition={{ duration: 0.7, delay: reduceMotion ? 0 : delay, ease: EASE_OUT }}
    >
      {children}
    </motion.div>
  );
}

/** Wrap a list of children so they cascade in one after another. */
export function Stagger({ children, className = "", stagger = 0.08, delay = 0 }: { children: ReactNode; className?: string; stagger?: number; delay?: number }) {
  const reduceMotion = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduceMotion ? false : "hidden"}
      whileInView="show"
      viewport={{ once: true, amount: 0.12, margin: "0px 0px -40px 0px" }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: stagger, delayChildren: delay } } }}
    >
      {children}
    </motion.div>
  );
}

/** Child item for <Stagger>. */
export function StaggerItem({ children, className = "", direction = "up", distance = 24 }: { children: ReactNode; className?: string; direction?: Direction; distance?: number }) {
  return (
    <motion.div
      className={className}
      variants={{
        hidden: { opacity: 0, ...offsetFor(direction, distance) },
        show: { opacity: 1, x: 0, y: 0, transition: { duration: 0.65, ease: EASE_OUT } },
      }}
    >
      {children}
    </motion.div>
  );
}

/** Element drifts vertically at a different rate than the page while it passes through the viewport. */
export function Parallax({ children, className = "", speed = 0.25, style }: { children: ReactNode; className?: string; speed?: number; style?: CSSProperties }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const raw = useTransform(scrollYProgress, [0, 1], [speed * 120, speed * -120]);
  const y = useSpring(raw, { stiffness: 90, damping: 26, mass: 0.6 });
  return (
    <motion.div ref={ref} className={className} style={{ ...style, y: reduceMotion ? 0 : y }}>
      {children}
    </motion.div>
  );
}

/** Animates a number from 0 to `value` the first time it scrolls into view. */
export function CountUp({
  value, prefix = "", suffix = "", decimals = 0, duration = 1.6, className = "",
}: { value: number; prefix?: string; suffix?: string; decimals?: number; duration?: number; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "0px 0px -10% 0px" });
  const reduceMotion = useReducedMotion();
  const [display, setDisplay] = useState(reduceMotion ? value : 0);

  useEffect(() => {
    if (!inView) return;
    if (reduceMotion) { setDisplay(value); return; }
    const controls = animate(0, value, {
      duration,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (v) => setDisplay(v),
    });
    return () => controls.stop();
  }, [inView, value, duration, reduceMotion]);

  const text = display.toLocaleString("en-IN", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return (
    <span ref={ref} className={`price-value ${className}`} aria-label={`${prefix}${value.toLocaleString("en-IN", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}${suffix}`}>
      {prefix}{text}{suffix}
    </span>
  );
}

/** A vertical/horizontal line that "draws" itself as the user scrolls through its container. */
export function ScrollLine({ containerRef, orientation = "horizontal", className = "" }: { containerRef: React.RefObject<HTMLElement | null>; orientation?: "horizontal" | "vertical"; className?: string }) {
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ["start 80%", "end 45%"] });
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 28 });
  const scale: MotionValue<number> = reduceMotion ? scrollYProgress : progress;
  return (
    <motion.div
      aria-hidden="true"
      className={className}
      style={orientation === "horizontal" ? { scaleX: scale, transformOrigin: "left center" } : { scaleY: scale, transformOrigin: "center top" }}
    />
  );
}

/** Scales, fades and blurs content as it scrolls out of the top of the viewport (for hero sections). */
export function useScrollFade(ref: React.RefObject<HTMLElement | null>) {
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const opacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.94]);
  const y = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const blur = useTransform(scrollYProgress, [0, 0.7], ["blur(0px)", "blur(6px)"]);
  return reduceMotion
    ? { opacity: 1, scale: 1, y: 0, filter: "none" }
    : { opacity, scale, y, filter: blur };
}

/** Tilt-on-hover card with a subtle spotlight that follows the cursor. Falls back to a plain div when reduced motion is set. */
export function TiltCard({ children, className = "", max = 6 }: { children: ReactNode; className?: string; max?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const [transform, setTransform] = useState("perspective(900px) rotateX(0deg) rotateY(0deg)");
  const [spot, setSpot] = useState({ x: 50, y: 50, on: false });

  const onMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (reduceMotion || e.pointerType === "touch" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    setTransform(`perspective(900px) rotateX(${(0.5 - py) * max * 2}deg) rotateY(${(px - 0.5) * max * 2}deg)`);
    setSpot({ x: px * 100, y: py * 100, on: true });
  };
  const reset = () => { setTransform("perspective(900px) rotateX(0deg) rotateY(0deg)"); setSpot((s) => ({ ...s, on: false })); };

  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={reset}
      className={`tilt-card ${className}`}
      style={{ transform, ["--spot-x" as string]: `${spot.x}%`, ["--spot-y" as string]: `${spot.y}%`, ["--spot-o" as string]: spot.on ? 1 : 0 } as CSSProperties}
    >
      {children}
    </div>
  );
}

/** Marquee strip that scrolls horizontally, direction reverses with scroll direction. */
export function ScrollMarquee({ items, className = "" }: { items: string[]; className?: string }) {
  const { scrollY } = useScroll();
  const reduceMotion = useReducedMotion();
  const baseX = useRef(0);
  const [x, setX] = useState(0);
  const dir = useRef(1);
  const lastY = useRef(0);

  useMotionValueEvent(scrollY, "change", (y) => {
    dir.current = y > lastY.current ? 1 : -1;
    lastY.current = y;
  });

  useEffect(() => {
    if (reduceMotion) return;
    let frame = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      baseX.current -= dir.current * 40 * dt;
      // Wrap within one copy of the track; content is duplicated so this is seamless.
      if (baseX.current <= -50) baseX.current += 50;
      if (baseX.current > 0) baseX.current -= 50;
      setX(baseX.current);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [reduceMotion]);

  const track = [...items, ...items];
  return (
    <div className={`overflow-hidden ${className}`} aria-hidden="true">
      <div className="flex w-max whitespace-nowrap will-change-transform" style={{ transform: `translateX(${x}%)` }}>
        {track.map((item, i) => (
          <span key={i} className="flex items-center gap-6 px-6 font-label-caps text-[11px] font-bold uppercase tracking-[0.22em] text-primary/55">
            {item}<span className="h-1 w-1 rounded-full bg-tertiary" />
          </span>
        ))}
      </div>
    </div>
  );
}

export function BackToTop() {
  const { scrollY, scrollYProgress } = useScroll();
  const [visible, setVisible] = useState(false);
  const reducedMotion = useReducedMotion();
  const progress = useSpring(scrollYProgress, { stiffness: 140, damping: 30 });
  const dash = useTransform(progress, [0, 1], [113, 0]); // circumference of r=18 ≈ 113
  useMotionValueEvent(scrollY, "change", (y) => setVisible(y > 900));

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 12 }}
          onClick={() => window.scrollTo({ top: 0, behavior: reducedMotion ? "instant" : "smooth" })}
          aria-label="Back to top"
          className="interactive-button fixed bottom-5 right-5 z-30 grid h-12 w-12 place-items-center rounded-full border border-tertiary/30 bg-surface/95 text-primary shadow-lg backdrop-blur-md sm:bottom-7 sm:right-7"
        >
          <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 40 40" aria-hidden="true">
            <circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" strokeOpacity="0.12" strokeWidth="2" />
            <motion.circle cx="20" cy="20" r="18" fill="none" stroke="#755b00" strokeWidth="2" strokeLinecap="round" strokeDasharray="113" style={{ strokeDashoffset: dash }} />
          </svg>
          <ArrowUp size={17} aria-hidden="true" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
